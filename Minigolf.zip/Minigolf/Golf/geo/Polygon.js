class Polygon extends Geometry {
    constructor() {
        super();
    }
}