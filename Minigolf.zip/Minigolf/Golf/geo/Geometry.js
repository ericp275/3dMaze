class Geometry{
    constructor(){
      
      
    }
  
  }