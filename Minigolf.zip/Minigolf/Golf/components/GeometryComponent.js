class GeometryComponent extends Component{
    constructor(geometry){
      super();
      this.Geometry = geometry;
  
    }
  }