class GeometryRendererComponent extends RendererComponent {
    constructor(color, geometry) {
      super()
      this.color;
      this.geometry;
      this.visible = true;
      this.vertices = [];
  
      // Check the arguments. We expect exactly two. 
      // The first is a color
      // The second is a geometry
  
      this.color = color;
      this.geometry = geometry;
    }
  
    render(ctx, gameObject) {
  
      ctx.fillStyle = this.color;
  
      if (this.geometry instanceof AxisAlignedRectangle) {
        let width = this.geometry.widthHeight.x;
        let height = this.geometry.widthHeight.y;
  
        let x = -width / 2;
        let y = -height / 2;
  
        ctx.fillRect(x, y, width, height);
  
      }

      else if (this.geometry instanceof Wall) {
        let width = this.geometry.width;
        let height = this.geometry.height;

        let A = this.geometry.coefficients.A;
        let B = this.geometry.coefficients.B;
        ctx.strokeStyle = this.color;
        ctx.lineWidth = .05;
        ctx.beginPath();
        ctx.moveTo(0 + .25 * A - .25 * B, 0 + .25 * A + .25 * B);
        ctx.lineTo(width * A - .25 * A - .25 * B, width * B + .25 * A - .25 * B);
        ctx.lineTo(width * A - height * B - .25 * A + .25 * B, width * B + (height * A) - .25 * A - .25 * B);
        ctx.lineTo(-(height * B) + .25 * A + .25 * B, (height * A) - .25 * A + .25 * B);
        ctx.fill();
      }

      else if (this.geometry instanceof Circle) {
        if(this.visible){
        ctx.fillStyle = this.color;
  
        ctx.beginPath();
        ctx.ellipse(0, 0, this.geometry.radius, this.geometry.radius, 0, 0, Math.PI * 2);
        ctx.fill();
        }
      }


      else if (this.geometry instanceof Ellipse) {
        ctx.fillStyle = this.color;
        let length = this.geometry.length;
        
  
        ctx.beginPath();
        ctx.ellipse( 0, 0, length, this.geometry.width, this.geometry.angle, 0, Math.PI * 2);
        ctx.fill();
      }


      else if (this.geometry instanceof Vector2) {
        ctx.strokeStyle = this.color;
        ctx.lineWidth = .05;
  
        ctx.beginPath();
        ctx.moveTo(this.geometry.x - .25, 0);
        ctx.lineTo(this.geometry.x + .25, 0);
        ctx.moveTo(0, this.geometry.y + .25);
        ctx.lineTo(0, this.geometry.y - .25);
        ctx.stroke();
  
       
      }

      else if (this.geometry instanceof Polygon) {
        ctx.strokeStyle = this.color;
        ctx.lineWidth = .05;
        
        //console.log(this.vertices);
        ctx.beginPath();
        ctx.moveTo(this.vertices[0].x, this.vertices[0].y);
        for(var i = this.vertices.length - 1; i >= 0; i--){
        ctx.lineTo(this.vertices[i].x, this.vertices[i].y);
        }
        ctx.fill();
      }
  
      else if (this.geometry instanceof Vector3) {
        ctx.strokeStyle = this.color;
        ctx.lineWidth = .1;
  
        ctx.beginPath();
        var i = 0;
        for( i = 0; i < 10; i+=2){
          let j = i + 1;
          ctx.moveTo((this.geometry.ball.x * i + this.geometry.force.x * (10 - i)) / 10, (this.geometry.ball.y * i + this.geometry.force.y * (10 - i)) / 10);
          ctx.lineTo((this.geometry.ball.x * j + this.geometry.force.x * (10 - j)) / 10, (this.geometry.ball.y * j + this.geometry.force.y * (10 - j)) / 10);
        }
        ctx.stroke();
  
       
      }
  
  
    }
  }