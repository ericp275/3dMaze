class Component{
  
}