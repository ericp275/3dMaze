var runStateHandler  = {
    start() {
      updateListeners.push(this);
      
      score = 0;
      this.maxObjects = 7;


      this.otherSquare = hierarchy[1];
      this.otherSquare.transform.position.x = -1;
      this.otherSquare.transform.position.y = -1;

      this.hole = hierarchy[0];
  

      
      this.square = new Good(10, 2);
      this.square2 = new Good(90, 4);
      this.square3 = new Good(120, 4);
      this.square2.transform.position.x = -2;
      this.square2.transform.position.y = -4;
      this.square3.transform.position.x = 4;
      this.square3.transform.position.y = 1;
      hierarchy.push(this.square);
      hierarchy.push(this.square2);
      hierarchy.push(this.square3);
      
  
      this.leaving = false;
      this.moving = false;
  
      this.cameraZoom = 50;
    },
    eventPump(event) {
      switch (event.name) {
        case "timer":
          this.update();
  
          for (let i = 0; i < hierarchy.length; i++) {
            var gameObject = hierarchy[i];
            let components = gameObject.components;
            for(let j = 0; j < components.length; j++){
              let component = components[j];
              if(component instanceof Behavior){
                if (typeof component.update === "function")
                  component.update(gameObject);
              }
            }
            
          }
          this.render();
          break;
        case "mousedown":
          if(!this.moving){
            if(hierarchy.length > this.maxObjects){
              hierarchy.pop;
            }
            console.log(this.otherSquare)
            let force = this.getAlteredCoordinates(event.location.x, event.location.y);
            this.aim = new Aimer(this.otherSquare.transform.position.x, this.otherSquare.transform.position.y, force.x, force.y);
            hierarchy.push(this.aim);
            console.log(hierarchy);
          }
          break;
        case "click":
          if(!this.moving){
            let ballAimer = hierarchy[hierarchy.length - 1];
            let ball = hierarchy[1];
            if( ballAimer instanceof Aimer){
              score += 1;
              ball.components[2].speed = ballAimer.getSpeed();
              this.moving = true;
              hierarchy.pop();
            }
          }
          //this.nextScene(); // Temporarily disable moving between scene
          break;
        case "mousemove":
          let aimer = hierarchy[hierarchy.length - 1];
          if( aimer instanceof Aimer){
            //console.log(aimer);
            //console.log(aimer.components[0]);
            if (event.location.x < 20 || event.location.x > width - 20 || event.location.y < 0 || event.location.y > height - 20){
                hierarchy.pop();
            }
            let location = this.getAlteredCoordinates(event.location.x, event.location.y);
            aimer.components[0].Geometry.force.y = location.y;
            aimer.components[0].Geometry.force.x = location.x;
          }
          
          break;
        case "mousewheel":
          if(event.delta < 0){
            this.cameraZoom *= 1.05;
          } else {
            this.cameraZoom /= 1.05;
          }
          console.log(this.cameraZoom);
          break;
      }
    },


    getAlteredCoordinates(x, y){
      x -= width / 2;
      y -= height / 2;
      x /= this.cameraZoom;
      y /= this.cameraZoom;
      y = -y;
      return {x: x, y: y};
    },

    isInCollision() {
      var p1 = this.square.transform.position;
      var p2 = this.otherSquare.transform.position;
  
      var xDiff = Math.abs(p1.x - p2.x);
      var yDiff = Math.abs(p1.y - p2.y);
      var d = Math.max(xDiff, yDiff);
      if (d < 2)
        return true;
      return false
    },
    nextScene() {
      state = END_STATE;
      updateListeners.splice(updateListeners.indexOf(this), 1);
      updateStateHandler();
    },

    update() {
      //This is where I update my model. I don't do any rendering here.
      if(this.otherSquare.components[2].speed.x == 0 && this.otherSquare.components[2].speed.y == 0){
        this.moving = false;
      }
      var hit = false;
      var speed = 5;
      let ballPosition = this.otherSquare.transform.position;
      ballSpeed = this.otherSquare.components[2].speed;
      for (var i = 0; i < hierarchy.length; i++) {
        let gameObject = hierarchy[i];
        if (gameObject instanceof Good){
          if(gameObject.containsPoint(ballPosition)){
            hit = true;
            if(this.leaving){
              console.log("leaving..");
              break;}
            console.log(ballPosition);
            let lastBallPosition = new Vector2(ballPosition.x - ballSpeed.x / 30, ballPosition.y - ballSpeed.y / 30);
            while(gameObject.containsPoint(lastBallPosition)){
              console.log("rewinding time...");
              lastBallPosition.x - ballSpeed.x / 30;
              lastBallPosition.y - ballSpeed.y / 30;
            }
            console.log(lastBallPosition);
            /*
            this.otherSquare.transform.position.x = lastBallPosition.x;
              this.otherSquare.transform.position.y = lastBallPosition.y;
              this.otherSquare.components[2].speed = new Vector2();
            */
            let newForce = gameObject.getDeflection(lastBallPosition, ballSpeed);
            this.otherSquare.components[2].speed = newForce;
            this.leaving = true;
            /*
            while(gameObject.containsPoint(this.otherSquare.transform.position)){
              console.log("Moving to: " + this.otherSquare.transform.position.x + ", " + this.otherSquare.transform.position.y);
              this.otherSquare.transform.position.x += newForce.x / 30;
              this.otherSquare.transform.position.y += newForce.y / 30;
            }
            */
            
            
          }
        } else if (gameObject instanceof Hole){
          let ballPosition = this.otherSquare.transform.position;
          let holePosition = gameObject.transform.position;
          let rise = holePosition.y - ballPosition.y;
          let run = holePosition.x - ballPosition.x;
          let distance = Math.sqrt(rise * rise + run * run);
          if(distance < .5){
              this.otherSquare.transform.position.x += run / 2;
              this.otherSquare.transform.position.y += rise / 2;
              if(!this.moving){
                console.log("Final Score: " + score);
                this.nextScene();
              }
          }
        }

        if(!hit){ this.leaving = false;}
        
      }


      
      //this.square.containsPoint(this.otherSquare.transform.position);
  /*
      if (this.isInCollision()) {
        console.log("boom");
        //this.newSquare();
      }
  */
  
    },
    render() {
      //This is where I render. I don't update my model here.
      ctx.fillStyle = "green";
      ctx.fillRect(0, 0, width, height);
  
      ctx.save(); {
        //Camera transformations
        ctx.translate(width / 2, height / 2);
        ctx.scale(this.cameraZoom, this.cameraZoom);
  
        ctx.save(); {
          //World transformation
          ctx.scale(1, -1);
  
  
          ctx.save(); {
  
  
            for (var i = 0; i < hierarchy.length; i++) {
              var gameObject = hierarchy[i];
  
              ctx.save(); {
                ctx.translate(gameObject.transform.position.x, gameObject.transform.position.y);
                ctx.scale(gameObject.transform.scale.x, gameObject.transform.scale.y);
  
                if (typeof gameObject.render === "function")
                  gameObject.render(ctx);
              }
              ctx.restore();
  
            }
          }
          ctx.restore();
        }
        ctx.restore();
      }
      ctx.restore();
      
      var rDimensions = positionGUI(width, height, .25, 20, .25)
  
      ctx.fillStyle = "rgba(255, 255, 255, .5)"
  
      ctx.fillRect(rDimensions.x,
        rDimensions.y,
        rDimensions.width,
        rDimensions.height);
  
  
      ctx.fillStyle = "black";
      ctx.font = "20px Arial";
  
      let string = "Shots: " + score;
  
      ctx.fillText(string, rDimensions.x + rDimensions.width / 2 - ctx.measureText(string).width / 2, rDimensions.y + 20);
      
  
    }
  };