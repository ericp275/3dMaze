var runStateHandler  = {
    start() {
      updateListeners.push(this);
      
      score = 0;
      this.maxObjects = 7;
      this.directionMaximums = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0];

      this.otherSquare = hierarchy[1];
      this.otherSquare.transform.position.x = -1;
      this.otherSquare.transform.position.y = -1;

      this.hole = hierarchy[0];
      this.prints = 1;

      
      this.square = new Good(135, 3);
      this.square2 = new Good(70, 4);
      this.square3 = new Good(170, 4);
      this.square.transform.position.x = -1;
      this.square.transform.position.y = -4;
      //this.square2.transform.position.x = -.5;
      this.square3.transform.position.x = 4;
      this.square3.transform.position.y = 1;
      hierarchy.push(this.square);
      hierarchy.push(this.square2);
      hierarchy.push(this.square3);


      var ang = 0;
      let ballPosition = this.otherSquare.transform.position;
      for(ang = 0; ang < 12; ang += 1){
        var rads = ang / 6 * 3.15
        var finished = false;
        this.directionMaximums[ang] = 2.5;
        while(!finished && this.directionMaximums[ang] > 0){
          finished = true;
          for (var i = 0; i < hierarchy.length; i++) {
            let gameObject = hierarchy[i];
            var deflection = {hit: false, forcex: 0, forcey: 0, locationx: 0, locationy: 0};
            if (gameObject instanceof Good){
              let lineEnd = {y: this.otherSquare.transform.position.y + this.directionMaximums[ang] * Math.cos(rads), x: this.otherSquare.transform.position.x + this.directionMaximums[ang] * Math.sin(rads)};

              deflection = gameObject.didShapeIntersect(ballPosition, lineEnd);
              if(deflection){
                this.directionMaximums[ang] -= .5;
                finished = false;
                break;
              } 
            }
          }
        }
      }
      for(ang = 0; ang < 12; ang += 1){
        var rads = ang / 6 * 3.14159
        var ellipse = new EllipseWall(.2, 0, .2);

        ellipse.transform.position.y = this.otherSquare.transform.position.y + this.directionMaximums[ang] * Math.cos(rads);
        ellipse.transform.position.x = this.otherSquare.transform.position.x + this.directionMaximums[ang] * Math.sin(rads);
      
        hierarchy.push(ellipse);
      }
  
      this.leaving = false;
      this.moving = false;
  
      this.cameraZoom = 50;
    },
    eventPump(event) {
      switch (event.name) {
        case "timer":
          this.update();
  
          for (let i = 0; i < hierarchy.length; i++) {
            var gameObject = hierarchy[i];
            if(gameObject instanceof Vector2){continue;}
            let components = gameObject.components;
            for(let j = 0; j < components.length; j++){
              let component = components[j];
              if(component instanceof Behavior){
                if (typeof component.update === "function")
                  component.update(gameObject);
              }
            }
            
          }
          this.render();
          break;
        case "mousedown":
          if(!this.moving){
            if(hierarchy.length > this.maxObjects){
              hierarchy.pop;
            }
            console.log(this.otherSquare)
            let force = this.getAlteredCoordinates(event.location.x, event.location.y);
            this.aim = new Aimer(this.otherSquare.transform.position.x, this.otherSquare.transform.position.y, force.x, force.y);
            hierarchy.push(this.aim);
            console.log(hierarchy);
          }
          break;
        case "click":
          if(!this.moving){
            let ballAimer = hierarchy[hierarchy.length - 1];
            let ball = hierarchy[1];
            if( ballAimer instanceof Aimer){
              score += 1;
              ball.components[2].speed = ballAimer.getSpeed();
              this.moving = true;
              this.prints = 0;
              hierarchy.pop();
            }
          }
          //this.nextScene(); // Temporarily disable moving between scene
          break;
        case "mousemove":
          let aimer = hierarchy[hierarchy.length - 1];
          if( aimer instanceof Aimer){
            //console.log(aimer);
            //console.log(aimer.components[0]);
            if (event.location.x < 20 || event.location.x > width - 20 || event.location.y < 20 || event.location.y > height - 20){
                hierarchy.pop();
            }
            let location = this.getAlteredCoordinates(event.location.x, event.location.y);
            let ball = this.otherSquare.transform.position;
            let distance = Math.sqrt((location.x - ball.x) * (location.x - ball.x) + (location.y - ball.y) * (location.y - ball.y));
            let slope = Math.atan((location.y - ball.y) / (location.x - ball.x));
            console.log("slope:" + slope);
            if(distance < 2.5){
              aimer.components[0].Geometry.force.y = location.y;
              aimer.components[0].Geometry.force.x = location.x;
            }
          }
          
          break;
        case "mousewheel":
          if(event.delta < 0){
            this.cameraZoom *= 1.05;
          } else {
            this.cameraZoom /= 1.05;
          }
          console.log(this.cameraZoom);
          break;
      }
    },


    getAlteredCoordinates(x, y){
      x -= width / 2;
      y -= height / 2;
      x /= this.cameraZoom;
      y /= this.cameraZoom;
      y = -y;
      return {x: x, y: y};
    },

    isInCollision() {
      var p1 = this.square.transform.position;
      var p2 = this.otherSquare.transform.position;
  
      var xDiff = Math.abs(p1.x - p2.x);
      var yDiff = Math.abs(p1.y - p2.y);
      var d = Math.max(xDiff, yDiff);
      if (d < 2)
        return true;
      return false
    },
    nextScene() {
      state = END_STATE;
      updateListeners.splice(updateListeners.indexOf(this), 1);
      updateStateHandler();
    },

    update() {
      //This is where I update my model. I don't do any rendering here.
      if(this.otherSquare.components[2].speed.x == 0 && this.otherSquare.components[2].speed.y == 0){
        this.moving = false;
      }

      let ballPosition = this.otherSquare.transform.position;
      ballSpeed = this.otherSquare.components[2].speed;
      var deflection = {hit: false, forcex: 0, forcey: 0, locationx: 0, locationy: 0};
      for (var i = 0; i < hierarchy.length; i++) {
        let gameObject = hierarchy[i];
        if (gameObject instanceof Good && this.moving){
          //console.log("check object " + i);
          possibleDeflection = gameObject.getDeflection2(ballPosition, ballSpeed, this.prints)
          if(possibleDeflection.hit){
            console.log("hit object " + i);
            if(deflection.hit) {
              if(Math.abs(possibleDeflection.locationx - ballPosition.x + ballSpeed.x / 30) < Math.abs(deflection.locationx - ballPosition.x + ballSpeed.x / 30)){
                deflection = possibleDeflection;
              }
            } else {
            deflection = possibleDeflection;
            }
          }
           
        } else if (gameObject instanceof Hole){
          let ballPosition = this.otherSquare.transform.position;
          let holePosition = gameObject.transform.position;
          let rise = holePosition.y - ballPosition.y;
          let run = holePosition.x - ballPosition.x;
          let distance = Math.sqrt(rise * rise + run * run);
          if(distance < .5){
              this.otherSquare.transform.position.x += run / 2;
              this.otherSquare.transform.position.y += rise / 2;
              if(!this.moving){
                console.log("Final Score: " + score);
                this.nextScene();
              }
          }
        }

      }
      this.prints = 1;
      if(deflection.hit){
        this.otherSquare.transform.position.x = deflection.locationx;
        this.otherSquare.transform.position.y = deflection.locationy;
        console.log("moved ball to " + deflection.locationx + ", " + deflection.locationy);
        this.otherSquare.components[2].speed.x = deflection.forcex;
        this.otherSquare.components[2].speed.y = deflection.forcey;
      }


  
    },
    render() {
      //This is where I render. I don't update my model here.
      ctx.fillStyle = "green";
      ctx.fillRect(0, 0, width, height);
  
      ctx.save(); {
        //Camera transformations
        ctx.translate(width / 2, height / 2);
        ctx.scale(this.cameraZoom, this.cameraZoom);
  
        ctx.save(); {
          //World transformation
          ctx.scale(1, -1);
  
  
          ctx.save(); {
  
  
            for (var i = 0; i < hierarchy.length; i++) {
              var gameObject = hierarchy[i];
  
              ctx.save(); {
                ctx.translate(gameObject.transform.position.x, gameObject.transform.position.y);
                ctx.scale(gameObject.transform.scale.x, gameObject.transform.scale.y);
  
                if (typeof gameObject.render === "function")
                  gameObject.render(ctx);
              }
              ctx.restore();
  
            }
          }
          ctx.restore();
        }
        ctx.restore();
      }
      ctx.restore();
      
      var rDimensions = positionGUI(width, height, .25, 20, .25)
  
      ctx.fillStyle = "rgba(255, 255, 255, .5)"
  
      ctx.fillRect(rDimensions.x,
        rDimensions.y,
        rDimensions.width,
        rDimensions.height);
  
  
      ctx.fillStyle = "black";
      ctx.font = "20px Arial";
  
      let string = "Shots: " + score;
  
      ctx.fillText(string, rDimensions.x + rDimensions.width / 2 - ctx.measureText(string).width / 2, rDimensions.y + 20);
      
  
    }
  };