var designStateHandler = {
    start() {
      updateListeners.push(this);
      this.timeCount = 0;
      this.cameraZoom = 50;

      this.firstClick = true;
      this.wallStart = new Vector2();

      this.otherSquare = new Bad();
      this.otherSquare.transform.position.x = -1;
      this.otherSquare.transform.position.y = -1;
  

      this.hole = new Hole();
      this.hole.transform.position.x = 3;
      this.hole.transform.position.y = 4;
  
      
      

      this.wall1 = new Good(90, 14);
      this.wall2 = new Good(0, 14);
      this.wall3 = new Good(90, 14);
      this.wall4 = new Good(0, 14);
      //var point = getAlteredCoordinates(width, height);
      this.wall1.transform.position.x = -7;
      this.wall1.transform.position.y = -7;
      this.wall2.transform.position.x = -6;
      this.wall2.transform.position.y = -7;
      this.wall3.transform.position.x = -7;
      this.wall3.transform.position.y = 6;
      this.wall4.transform.position.x = 7;
      this.wall4.transform.position.y = -7;
  
      hierarchy.push(this.hole);
      hierarchy.push(this.otherSquare);
      hierarchy.push(this.wall1);
      hierarchy.push(this.wall2);
      hierarchy.push(this.wall3);
      hierarchy.push(this.wall4);

      this.render();


    },
    eventPump(event) {
      switch (event.name) {      
        case "timer":
          this.update();
          this.render();
          break;
        case "click":
            if(this.firstClick){
                this.wallStart = this.getAlteredCoordinates(event.location.x, event.location.y);
                console.log("firstClick:" + this.wallStart.x + ", " + this.wallStart.y);
                this.firstClick = false;
            } else {
                newPoint = this.getAlteredCoordinates(event.location.x, event.location.y);
                let rise = newPoint.y - this.wallStart.y;
                let run = newPoint.x - this.wallStart.x;
                let slope = rise / run;
                console.log("Slope: " + slope);
                let angle = Math.atan(slope) / 3.14159 * 180;
                angle -= 90;
                if (angle < 0){
                    angle += 180;
                }
                console.log("Angle: " + angle);
                let distance = Math.sqrt(rise * rise + run * run) + .5;
                console.log("Distance: " + distance);
                let wall = new Good(angle, distance);
                let A = wall.components[1].geometry.coefficients.A;
                let B = wall.components[1].geometry.coefficients.B;
                if(angle <= 90){
                    wall.transform.position.x = this.wallStart.x - .25 * A + .25 * B;
                    wall.transform.position.y = this.wallStart.y - .25 * A - .25 * B;
                } else {
                    wall.transform.position.x = newPoint.x;
                    wall.transform.position.y = newPoint.y;
                }
                hierarchy.push(wall);
                this.firstClick = true;
            }
          break;
        case "startGame":
            this.nextScene();
          break;
      }
    },
    nextScene() {
      state = RUN_STATE;
      updateListeners.splice(updateListeners.indexOf(this), 1);
      updateStateHandler();
    },

    getAlteredCoordinates(x, y){
        x -= width / 2;
        y -= height / 2;
        x /= this.cameraZoom;
        y /= this.cameraZoom;
        y = -y;
        return {x: x, y: y};
      },

    update() {
      //This is where I update my model. I don't do any rendering here.
      
    },


    render() {
      //This is where I render. I don't update my model here.   
  
      ctx.fillStyle = "green";
      ctx.fillRect(0, 0, width, height);

      ctx.save(); {
        //Camera transformations
        ctx.translate(width / 2, height / 2);
        ctx.scale(this.cameraZoom, this.cameraZoom);
  
        ctx.save(); {
          //World transformation
          ctx.scale(1, -1);
  
  
          ctx.save(); {
  
  
            for (var i = 0; i < hierarchy.length; i++) {
              var gameObject = hierarchy[i];
  
              ctx.save(); {
                ctx.translate(gameObject.transform.position.x, gameObject.transform.position.y);
                ctx.scale(gameObject.transform.scale.x, gameObject.transform.scale.y);
  
                if (typeof gameObject.render === "function")
                  gameObject.render(ctx);
              }
              ctx.restore();
  
            }
          }
          ctx.restore();
        }
        ctx.restore();
      }
      ctx.restore();
      

  
      var rDimensions = positionGUI(width, height, .25, 20, .25)
  
      ctx.fillStyle = "rgba(255, 255, 255, .5)"
  
      ctx.fillRect(rDimensions.x,
        rDimensions.y,
        rDimensions.width,
        rDimensions.height);
  
  
      ctx.fillStyle = "black";
      ctx.font = "20px Arial";
  
      let string = "Design your Mini-Golf Course!";
  
      ctx.fillText(string, rDimensions.x + rDimensions.width / 2 - ctx.measureText(string).width / 2, rDimensions.y + 20);
    }
  };