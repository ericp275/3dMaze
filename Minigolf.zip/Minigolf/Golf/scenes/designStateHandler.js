var designStateHandler = {
    start() {
      updateListeners.push(this);
      this.cameraZoom = 50;
      this.firstClick = true;
      this.connected = false;
      this.wallStarted = false;
      this.wallStart = new Vector2();
      this.wallEnd = new Vector2();
      this.connector = new WallConnect();
      this.connector.transform.position.x = 500;
      this.connector.transform.position.y = 500;
      this.connector.components[1].visible = false;
      this.links = 1;
      this.adder = new WallConnect();
      this.adder.transform.position.x = 500;
      this.adder.transform.position.y = 500;
      this.adder.components[1].color = "red";

      if(!initialized){

      this.otherSquare = new Bad();
      this.otherSquare.transform.position.x = -1;
      this.otherSquare.transform.position.y = -1;
  

      this.hole = new Hole();
      this.hole.transform.position.x = 3;
      this.hole.transform.position.y = 4;
  
      
      

      this.wall1 = new Boarder(90, 20);
      this.wall2 = new Boarder(0, 20);
      this.wall3 = new Boarder(90, 20);
      this.wall4 = new Boarder(0, 20);
      //var point = getAlteredCoordinates(width, height);
      this.wall1.transform.position.x = -10;
      this.wall1.transform.position.y = -10;
      this.wall2.transform.position.x = -9;
      this.wall2.transform.position.y = -10;
      this.wall3.transform.position.x = -10;
      this.wall3.transform.position.y = 9;
      this.wall4.transform.position.x = 10;
      this.wall4.transform.position.y = -10;
  
      hierarchy.push(this.hole);
      hierarchy.push(this.otherSquare);
      hierarchy.push(this.wall1);
      hierarchy.push(this.wall2);
      hierarchy.push(this.wall3);
      hierarchy.push(this.wall4);
      }
      initialized = true;

      this.render();


    },
    eventPump(event) {
      switch (event.name) {      
        case "timer":
          this.update();
          this.render();
          break;
        case "click":
          this.connector.components[1].visible = false;
            if(this.connected && this.getDistance(this.getAlteredCoordinates(event.location.x, event.location.y), this.connector.transform.position) < .25){
              this.makePolygon();
              this.firstClick = true;
              this.connected = false;
              this.wallStarted = false;
              this.adder.components[1].visible = false;
              this.connector.components[1].visible = false;
            }
            else if(this.firstClick){
                this.wallStart = this.getAlteredCoordinates(event.location.x, event.location.y);
                console.log("firstClick:" + this.wallStart.x + ", " + this.wallStart.y);
                newPoint = this.getAlteredCoordinates(event.location.x, event.location.y);
                wall = this.getWall(newPoint);
                if(this.getDistance(this.getAlteredCoordinates(event.location.x, event.location.y), this.adder.transform.position) < .25){
                  this.links += 1;
                  console.log("links: " + this.links);
                  if(this.links > 2){
                    this.connected = true;
                    this.connector.components[1].visible = true;
                  }
                } else {
                  this.links = 1;
                  console.log("links: " + this.links);
                  this.connector.transform.position.x = this.wallStart.x;
                  this.connector.transform.position.y = this.wallStart.y;
                  hierarchy.push(this.connector);
                  this.connected = false;
                  this.adder.components[1].visible = false;
                }
                hierarchy.push(wall);
                this.firstClick = false;
            } else {
              this.wallEnd = this.getAlteredCoordinates(event.location.x, event.location.y);
              this.adder.transform.position.x = this.wallEnd.x;
              this.adder.transform.position.y = this.wallEnd.y;
              hierarchy.push(this.adder);
              this.firstClick = true;
              this.wallStarted = true;
              this.connected = false;
              this.adder.components[1].visible = true;
            }
          break;
        case "mousemove":
          if(!this.firstClick){
            newPoint = this.getAlteredCoordinates(event.location.x, event.location.y);
            hierarchy[hierarchy.length - 1] = this.getWall(newPoint);
          }
          break;
        case "mousewheel":
          if(event.delta < 0){
            this.cameraZoom *= 1.05;
          } else {
            this.cameraZoom /= 1.05;
          }
          console.log(this.cameraZoom);
          break;
        case "startGame":
            this.nextScene();
          break;
        case "boarderToggle":
            this.createBoarders();
            break;
      }
    },


    getDistance(event, point){
      return Math.sqrt((event.x - point.x) * (event.x - point.x) + (event.y - point.y) * (event.y - point.y));
    },

    makePolygon(){
      console.log("making Polygon");
      console.log(hierarchy);
      let vertices = [];
      while(this.links > 0){
        let wall = hierarchy.pop();//hierarchy[hierarchy.length - 1];
        console.log(wall);
        if(wall instanceof Good){
          let point = wall.start;
          vertices.push(point);
          this.links -= 1;
        }
      }
      let convexObstacle = new ConvexObstacle(vertices);
      console.log(convexObstacle);
      hierarchy.push(convexObstacle);
      console.log(hierarchy);
    },

    getWall(newPoint){
      let rise = newPoint.y - this.wallStart.y;
      let run = newPoint.x - this.wallStart.x;
      let slope = rise / run;
      //console.log("Slope: " + slope);
      let angle = Math.atan(slope) / 3.14159 * 180;
      //console.log("Angle: " + angle);
      if(newPoint.x < this.wallStart.x){
        angle += 180;

      } else if (angle < 0){
        angle = 360 + angle;
      }

      //console.log("360Angle: " + angle);
      var alteredAngle = 0;

      if(angle > 0 && angle <= 90){
        alteredAngle = 90 - angle;
      } else if (angle > 90 && angle <= 270){
        alteredAngle = 270 - angle;
      } else {
        alteredAngle =  450 - angle;
      }

      var shiftedAngle = angle;
      if (angle < 0){
          shiftedAngle += 180;
      }
      //console.log("CorrectedAngle: " + alteredAngle);
      let distance = Math.sqrt(rise * rise + run * run) + .5;
      //console.log("Distance: " + distance);
      let wall = new Good(alteredAngle, distance);
      
      let A = wall.components[1].geometry.coefficients.A;
      let B = wall.components[1].geometry.coefficients.B;
      var xshift = 0;
      var yshift = 0;
      if (90 < angle && angle < 180){
        xshift = -A / 2;
        yshift = -B / 2;
      } else if (180 <= angle && angle < 270){
        xshift = B / 2;
        yshift = -A / 2;
      }

      if(shiftedAngle < 180){
          wall.transform.position.x = this.wallStart.x - .25 * A + .25 * B + xshift;
          wall.transform.position.y = this.wallStart.y - .25 * A - .25 * B + yshift;
      } else {
          wall.transform.position.x = newPoint.x  - .25 * A + .25 * B + xshift;
          wall.transform.position.y = newPoint.y  - .25 * A - .25 * B + yshift;
      }
      wall.start = newPoint;
      return wall;
    },


    nextScene() {
      state = RUN_STATE;
      updateListeners.splice(updateListeners.indexOf(this), 1);
      updateStateHandler();
    },

    createBoarders() {
      state = BOARDER_CREATION_STATE;
      updateListeners.splice(updateListeners.indexOf(this), 1);
      updateStateHandler();
    },

    getAlteredCoordinates(x, y){
        x -= width / 2;
        y -= height / 2;
        x /= this.cameraZoom;
        y /= this.cameraZoom;
        y = -y;
        return {x: x, y: y};
      },

    update() {
      //This is where I update my model. I don't do any rendering here.
      
    },


    render() {
      //This is where I render. I don't update my model here.   
  
      ctx.fillStyle = "green";
      ctx.fillRect(0, 0, width, height);

      ctx.save(); {
        //Camera transformations
        ctx.translate(width / 2, height / 2);
        ctx.scale(this.cameraZoom, this.cameraZoom);
  
        ctx.save(); {
          //World transformation
          ctx.scale(1, -1);
  
  
          ctx.save(); {
  
  
            for (var i = 0; i < hierarchy.length; i++) {
              var gameObject = hierarchy[i];
  
              ctx.save(); {
                ctx.translate(gameObject.transform.position.x, gameObject.transform.position.y);
                ctx.scale(gameObject.transform.scale.x, gameObject.transform.scale.y);
  
                if (typeof gameObject.render === "function")
                  gameObject.render(ctx);
              }
              ctx.restore();
  
            }
          }
          ctx.restore();
        }
        ctx.restore();
      }
      ctx.restore();
      

  
      var rDimensions = positionGUI(width, height, .25, 20, .25)
  
      ctx.fillStyle = "rgba(255, 255, 255, .5)"
  
      ctx.fillRect(rDimensions.x,
        rDimensions.y,
        rDimensions.width,
        rDimensions.height);
  
  
      ctx.fillStyle = "black";
      ctx.font = "20px Arial";
  
      let string = "Design your Mini-Golf Course!";
  
      ctx.fillText(string, rDimensions.x + rDimensions.width / 2 - ctx.measureText(string).width / 2, rDimensions.y + 20);
    }
  };