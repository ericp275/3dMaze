class BadSquareBehavior extends Behavior{
    constructor(){
      super();
      this.speed = new Vector2();
  
    }
    update(){
      if (Math.abs(this.speed.x) + Math.abs(this.speed.y) > .5) {
        this.transform.position.x += this.speed.x / 30; /// speed is in units/s * s
        this.transform.position.y += this.speed.y /30;
        this.speed.scale(.98);
        //console.log(this.speed)
        //console.log("X-->", this.transform.position.x);
        //console.log("Y-->" + this.transform.position.y);
      }
      else {
          this.speed = new Vector2();
      }
    }
    
  
  }