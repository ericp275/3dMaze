class ConvexObstacle extends Obstacle{
    constructor(vertices){
        super();
        this.vertices = vertices;
        var myGeometry = new ob(a,b);
        console.log("Made shape with " + this.vertices.length + " sides.");
        var myGeometryComponent = new GeometryComponent(myGeometry);
        this.components.push(myGeometryComponent);
    
        var myRenderer = new GeometryRendererComponent("grey", myGeometry);
        this.components.push(myRenderer);
        this.renderer = myRenderer;
    
        var myBehavior = new GoodSquareBehavior();
        myBehavior.transform = this.transform;
        this.components.push(myBehavior);  
  
      }
}