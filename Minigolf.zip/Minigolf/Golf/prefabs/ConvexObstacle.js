class ConvexObstacle extends Obstacle{
    constructor(vertices){
        super();
        this.vertices = vertices;
        var myGeometry = new Polygon();
        console.log("Made shape with " + this.vertices.length + " sides.");
        var myGeometryComponent = new GeometryComponent(myGeometry);
        this.components.push(myGeometryComponent);
    
        var myRenderer = new GeometryRendererComponent("grey", myGeometry);
        myRenderer.vertices = vertices;
        this.components.push(myRenderer);
        this.renderer = myRenderer;
        
  
      }
}