class EllipseWall extends GameObject {
    constructor(l, a, w){
      super(); 
      a = a / 180 * 3.14159;   
  
      var myGeometry = new Ellipse(l , a, w);
      var myGeometryComponent = new GeometryComponent(myGeometry);
      this.components.push(myGeometryComponent);
  
      var myRenderer = new GeometryRendererComponent("red", myGeometry);
      this.components.push(myRenderer);
      this.renderer = myRenderer;

    }
    
    
  } 