class Bad extends GameObject {
    constructor(){
      super();    
  
      var myGeometry = new Circle(.25);
      var myGeometryComponent = new GeometryComponent(myGeometry);
      this.components.push(myGeometryComponent);
  
      var myRenderer = new GeometryRendererComponent("white", myGeometry);
      this.components.push(myRenderer);
      this.renderer = myRenderer;

      var myBehavior = new BadSquareBehavior();
      myBehavior.transform = this.transform;
      this.components.push(myBehavior);
    }
    
    
  } 