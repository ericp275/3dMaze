class Obstacle extends GameObject {

    constructor(){
        super();


        this.vertices = [];
    }
}