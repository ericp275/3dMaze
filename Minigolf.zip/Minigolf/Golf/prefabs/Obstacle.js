class Obstacle extends GameObject {

    constructor(){
        super();


        this.vertices = [];
    }

    didShapeIntersect(lineStart, lineEnd){
        let shiftx = this.transform.position.x;
        let shifty = this.transform.position.y;
  
        
        var vertices = [];
        for (var i = 0; i < this.vertices.length; i++) {
          vertices.push( new Vector2(this.vertices[i].x + shiftx, this.vertices[i].y + shifty) );
        }
        for (var i = 0; i < vertices.length; i++) {
          var edgeFinish = vertices[0];
          if (i < vertices.length - 1){
            edgeFinish = vertices[i + 1];
          }
  
          if(this.didEdgeIntersect(lineStart, lineEnd, vertices[i], edgeFinish)){
            return true;
          }
          
          
        }
        return false;
      }
  
      didEdgeIntersect(lineStart, lineEnd, edgeStart, edgeFinish) {
  
        var deflection = false;
        var xIntersection = lineEnd.x;
        //console.log(lineStart.x + ", " + lineEnd.x + ", " + edgeFinish.x + ", " + edgeStart.x);
        if (edgeStart.x == edgeFinish.x){
          xIntersection = edgeFinish.x;
          
          if (xIntersection < lineStart.x && xIntersection > lineEnd.x ||
            xIntersection > lineStart.x && xIntersection < lineEnd.x){
              let ballSlope = (ballStarty - ballFinish.y) / (ballStartx - ballFinish.x);
              let yIntersection = ballStarty + ballSlope * Math.abs(ballStartx - xIntersection);
              console.log("Xhit at " + xIntersection + ", " + yIntersection);
              return true;
            }
        }
  
        if (lineEnd.x == lineStart.x){
          xIntersection = lineEnd.x;
          let edgeSlope = (edgeStart.y - edgeFinish.y) / (edgeStart.x - edgeFinish.x);
          let yIntersection = edgeStart.y + edgeSlope * Math.abs(edgeStart.x - xIntersection);
  
          if ((yIntersection < lineStart.y && yIntersection > lineEnd.y ||
            yIntersection > lineStart.y && yIntersection < lineEnd.y) && 
            (xIntersection < edgeFinish.x && xIntersection > edgeStart.x ||
              yIntersection > edgeFinish.x && yIntersection < edgeStart.x)){
              
              console.log("starty: " + lineStart.y + ", Endy: " + lineEnd.y);
              console.log("XXhit at " + xIntersection + ", " + yIntersection);
              return true;
            }
        }
  
        let edgeSlope = (edgeStart.y - edgeFinish.y) / (edgeStart.x - edgeFinish.x);
        let ballSlope = (lineStart.y - lineEnd.y) / (lineStart.x - lineEnd.x);
        let edgeIntercept = edgeStart.y - edgeSlope * edgeStart.x;
        let ballIntercept = lineStart.y - ballSlope * lineStart.x;
        //console.log("edge: Y = " + edgeSlope +  "X  + " + edgeIntercept);
        //console.log("aimer: Y = " + ballSlope +  "X  + " + ballIntercept);
        xIntersection = -(edgeIntercept - ballIntercept) / (edgeSlope - ballSlope);
        
        let yIntersection = ballSlope * xIntersection + ballIntercept;
        
        if ((xIntersection < lineStart.x && xIntersection > lineEnd.x ||
          xIntersection > lineStart.x && xIntersection < lineEnd.x) &&
          (xIntersection < edgeStart.x && xIntersection > edgeFinish.x ||
            xIntersection > edgeStart.x && xIntersection < edgeFinish.x) 
             ){
               /*
              console.log("edge: Y = " + edgeSlope +  "X  + " + edgeIntercept);
              console.log("aimer: Y = " + ballSlope +  "X  + " + ballIntercept);
              console.log("(" + xIntersection + ", " + yIntersection + ")");
              console.log("hit at " + xIntersection + ", " + yIntersection);;
              */
              return true;
        }
  
        return deflection;
      }

      edgeIntersection(ballFinish, force, edgeStart, edgeFinish, bestSoFar, prints) {

        let ballStartx = ballFinish.x - force.x / 30;
        let ballStarty = ballFinish.y - force.y / 30;
        var deflection = {hit: false, forcex: 0, forcey: 0, locationx: 0, locationy: 0};
        var xIntersection = ballFinish.x;
        if (edgeStart.x == edgeFinish.x){
          xIntersection = edgeFinish.x;
          if(Math.abs(xIntersection - ballStartx) > Math.abs(bestSoFar - ballStartx) ){
            return deflection;
          }
          if (xIntersection < ballStartx && xIntersection > ballFinish.x ||
            xIntersection > ballStartx && xIntersection < ballFinish.x){
              let ballSlope = (ballStarty - ballFinish.y) / (ballStartx - ballFinish.x);
              let yIntersection = ballStarty + ballSlope * Math.abs(ballStartx - xIntersection);
              let deflectionForce = this.getDeflectionWall(edgeStart, edgeFinish, force);
              console.log("hit at " + xIntersection + ", " + yIntersection);
              return {hit: true, forcex: deflectionForce.x, forcey: deflectionForce.y, locationx: xIntersection, locationy: yIntersection};
            }
        }
  
        if (ballStartx == ballFinish.x){
          xIntersection = ballFinish.x;
          if(Math.abs(xIntersection - ballStartx) > Math.abs(bestSoFar - ballStart.x) ){
            return deflection;
          }
          if (xIntersection < edgeStart.x && xIntersection > edgeFinish.x ||
            xIntersection > edgeStart.x && xIntersection < edgeFinish.x){
              let edgeSlope = (edgeStart.y - edgeFinish.y) / (edgeStart.x - edgeFinish.x);
              let yIntersection = edgeStart.y + edgeSlope * Math.abs(edgeStart.x - xIntersection);
              let deflectionForce = this.getDeflectionWall(edgeStart, edgeFinish, force);
              console.log("hit at " + xIntersection + ", " + yIntersection);
              return {hit: true, forcex: deflectionForce.x, forcey: deflectionForce.y, locationx: xIntersection, locationy: yIntersection};
            }
        }
  
        let edgeSlope = (edgeStart.y - edgeFinish.y) / (edgeStart.x - edgeFinish.x);
        let ballSlope = force.y / force.x;
        let edgeIntercept = edgeStart.y - edgeSlope * edgeStart.x;
        let ballIntercept = ballStarty - ballSlope * ballStartx;
        xIntersection = -(edgeIntercept - ballIntercept) / (edgeSlope - ballSlope);
        
        let yIntersection = ballSlope * xIntersection + ballIntercept;
        if(prints == 0){
          /*
          console.log("(" + ballStartx + ", " + ballStarty + "), (" + ballFinish.x + ", " + ballFinish.y + ")");
          console.log("Path: Y = " + ballSlope + "X + " + ballIntercept);
          console.log("(" + xIntersection + ", " + yIntersection + ")");
          /*
          console.log("Edge slope: " + edgeSlope);
          console.log("ball slope: " + ballSlope);
          console.log("Edge Intercept: " + edgeIntercept);
          console.log("ball slope: " + ballIntercept);
          console.log("Checking " + xIntersection + ", " + yIntersection);
          */
        }
        if ((xIntersection < ballStartx && xIntersection > ballFinish.x ||
          xIntersection > ballStartx && xIntersection < ballFinish.x) &&
          (xIntersection < edgeStart.x && xIntersection > edgeFinish.x ||
            xIntersection > edgeStart.x && xIntersection < edgeFinish.x) 
             ){
              console.log("edge: Y = " + edgeSlope +  "X  + " + edgeIntercept);
              console.log("ball: Y = " + ballSlope +  "X  + " + ballIntercept);
              console.log("(" + xIntersection + ", " + yIntersection + ")");
              let deflectionForce = this.getDeflectionWall(edgeStart, edgeFinish, force)
              console.log("hit at " + xIntersection + ", " + yIntersection);;
              return {hit: true, forcex: deflectionForce.x, forcey: deflectionForce.y, locationx: xIntersection, locationy: yIntersection};
        }
  
        return deflection;
      }

      
      getDeflection2(ballFinish, force, prints){
        var deflection = {hit: false, forcex: 0, forcey: 0, locationx: 0, locationy: 0};
        
        let shiftx = this.transform.position.x;
        let shifty = this.transform.position.y;
  
        
        var vertices = [];
        for (var i = 0; i < this.vertices.length; i++) {
          vertices.push( new Vector2(this.vertices[i].x + shiftx, this.vertices[i].y + shifty) );
        }
         
        var firstHit = 0;
        for (var i = 0; i < vertices.length; i++) {
          var edgeFinish = vertices[0];
          if (i < vertices.length - 1){
            edgeFinish = vertices[i + 1];
          }
  
          if( !deflection.hit){
            firstHit = edgeFinish.x;
          }
          let possibleDeflection = this.edgeIntersection(ballFinish, force, vertices[i], edgeFinish, firstHit, prints);
          if(possibleDeflection.hit){
            console.log("hit wall " + i);
            if(deflection.hit) {
              if(Math.abs(possibleDeflection.locationx - ballPosition.x + ballSpeed.x / 30) < Math.abs(deflection.locationx - ballPosition.x + ballSpeed.x / 30)){
                deflection = possibleDeflection;
              }
            } else {
            deflection = possibleDeflection;
            }
          }
          if(deflection.hit){
            firstHit = deflection.locationx;
          }
        }
  
        return deflection;
  
      }      

      getDeflectionWall(p, q, force){
        console.log("ForceIn: " + force.x + ", " + force.y)
        var wallAngle = 3.1416 / 2;
        if( p.x != q.x){
          console.log("rise: " + (p.y - q.y) + " run: " + (p.x - q.x))
          let slope = (p.y - q.y) / (p.x - q.x);
          wallAngle = Math.atan(slope);
        }
  
        
        console.log("wallAngle: " + wallAngle / 3.1415  * 180);
        var forceAngle = Math.atan(force.y / force.x);
        //console.log("forceAngle: " + forceAngle / 3.1415  * 180);
        if(force.x < 0){
          forceAngle += 3.14159;
        }
        console.log("forceAngle: " + forceAngle / 3.1415  * 180);
        let interceptAngle = forceAngle - wallAngle;
        //console.log(forceAngle + " - " + wallAngle + " = " + interceptAngle);
        let reflectionAngle = wallAngle - interceptAngle;
        //console.log(wallAngle + " - " + interceptAngle + " = " + reflectionAngle);
        console.log("reflectionAngle: " + reflectionAngle / 3.1415 * 180)
        let YXratio = Math.tan(reflectionAngle);
        console.log("YXratio: " + YXratio)
        let magnitude = Math.abs(force.x) + Math.abs(force.y);
        var newx = magnitude / (Math.abs(YXratio) + 1);
        //console.log
        if(reflectionAngle < -1.5708 && reflectionAngle > -4.712 || reflectionAngle > 1.5708){
          newx *= -1;
        }
        let newForce = new Vector2(newx, YXratio * newx);
        console.log("ForceOut:" + newForce.x + ", " + newForce.y)
        return new Vector2(newx, YXratio * newx);
      }
  
}