class Good extends Obstacle {
    constructor(a, b){
      super();
      
      var myGeometry = new Wall(a,b);
      //console.log("wall constructed: " + myGeometry.coefficients.A + ", " + myGeometry.coefficients.B + " Width: " + myGeometry.width);
      var myGeometryComponent = new GeometryComponent(myGeometry);
      this.components.push(myGeometryComponent);
  
      var myRenderer = new GeometryRendererComponent("grey", myGeometry);
      this.components.push(myRenderer);
      this.renderer = myRenderer;
  
      var myBehavior = new GoodSquareBehavior();
      myBehavior.transform = this.transform;
      this.components.push(myBehavior);



      let width = this.components[0].Geometry.width;
      let height = this.components[0].Geometry.height;
      let A = this.components[0].Geometry.coefficients.A;
      let B = this.components[0].Geometry.coefficients.B;
      let shiftx = this.transform.position.x;
      let shifty = this.transform.position.y;

      this.vertices.push( new Vector2(0 + shiftx, 0 + shifty) );
      this.vertices.push( new Vector2(width * A + shiftx, width * B + shifty) );
      this.vertices.push( new Vector2(width * A - (height * B) + shiftx, width * B + (height * A) + shifty) );
      this.vertices.push( new Vector2(-(height * B) + shiftx, (height * A) + shifty) );

      

    }
    
    
    getDeflection2(ballFinish, force, prints){
      var deflection = {hit: false, forcex: 0, forcey: 0, locationx: 0, locationy: 0};
      
      let shiftx = this.transform.position.x;
      let shifty = this.transform.position.y;

      
      var vertices = [];
      for (var i = 0; i < this.vertices.length; i++) {
        vertices.push( new Vector2(this.vertices[i].x + shiftx, this.vertices[i].y + shifty) );
      }
       
      var firstHit = 0;
      for (var i = 0; i < vertices.length; i++) {
        var edgeFinish = vertices[0];
        if (i < vertices.length - 1){
          edgeFinish = vertices[i + 1];
        }

        if( !deflection.hit){
          firstHit = edgeFinish.x;
        }
        let possibleDeflection = this.edgeIntersection(ballFinish, force, vertices[i], edgeFinish, firstHit, prints);
        if(possibleDeflection.hit){
          console.log("hit wall " + i);
          if(deflection.hit) {
            if(Math.abs(possibleDeflection.locationx - ballPosition.x + ballSpeed.x / 30) < Math.abs(deflection.locationx - ballPosition.x + ballSpeed.x / 30)){
              deflection = possibleDeflection;
            }
          } else {
          deflection = possibleDeflection;
          }
        }
        if(deflection.hit){
          firstHit = deflection.locationx;
        }
      }

      return deflection;

    }

    edgeIntersection(ballFinish, force, edgeStart, edgeFinish, bestSoFar, prints) {

      let ballStartx = ballFinish.x - force.x / 30;
      let ballStarty = ballFinish.y - force.y / 30;
      var deflection = {hit: false, forcex: 0, forcey: 0, locationx: 0, locationy: 0};
      var xIntersection = ballFinish.x;
      if (edgeStart.x == edgeFinish.x){
        xIntersection = edgeFinish.x;
        if(Math.abs(xIntersection - ballStartx) > Math.abs(bestSoFar - ballStartx) ){
          return deflection;
        }
        if (xIntersection < ballStartx && xIntersection > ballFinish.x ||
          xIntersection > ballStartx && xIntersection < ballFinish.x){
            let ballSlope = (ballStarty - ballFinish.y) / (ballStartx - ballFinish.x);
            let yIntersection = ballStarty + ballSlope * Math.abs(ballStartx - xIntersection);
            let deflectionForce = this.getDeflectionWall(edgeStart, edgeFinish, force);
            console.log("hit at " + xIntersection + ", " + yIntersection);
            return {hit: true, forcex: deflectionForce.x, forcey: deflectionForce.y, locationx: xIntersection, locationy: yIntersection};
          }
      }

      if (ballStartx == ballFinish.x){
        xIntersection = ballFinish.x;
        if(Math.abs(xIntersection - ballStartx) > Math.abs(bestSoFar - ballStart.x) ){
          return deflection;
        }
        if (xIntersection < edgeStart.x && xIntersection > edgeFinish.x ||
          xIntersection > edgeStart.x && xIntersection < edgeFinish.x){
            let edgeSlope = (edgeStart.y - edgeFinish.y) / (edgeStart.x - edgeFinish.x);
            let yIntersection = edgeStart.y + edgeSlope * Math.abs(edgeStart.x - xIntersection);
            let deflectionForce = this.getDeflectionWall(edgeStart, edgeFinish, force);
            console.log("hit at " + xIntersection + ", " + yIntersection);
            return {hit: true, forcex: deflectionForce.x, forcey: deflectionForce.y, locationx: xIntersection, locationy: yIntersection};
          }
      }

      let edgeSlope = (edgeStart.y - edgeFinish.y) / (edgeStart.x - edgeFinish.x);
      let ballSlope = force.y / force.x;
      let edgeIntercept = edgeStart.y - edgeSlope * edgeStart.x;
      let ballIntercept = ballStarty - ballSlope * ballStartx;
      xIntersection = -(edgeIntercept - ballIntercept) / (edgeSlope - ballSlope);
      
      let yIntersection = ballSlope * xIntersection + ballIntercept;
      if(prints == 0){
        /*
        console.log("(" + ballStartx + ", " + ballStarty + "), (" + ballFinish.x + ", " + ballFinish.y + ")");
        console.log("Path: Y = " + ballSlope + "X + " + ballIntercept);
        console.log("(" + xIntersection + ", " + yIntersection + ")");
        /*
        console.log("Edge slope: " + edgeSlope);
        console.log("ball slope: " + ballSlope);
        console.log("Edge Intercept: " + edgeIntercept);
        console.log("ball slope: " + ballIntercept);
        console.log("Checking " + xIntersection + ", " + yIntersection);
        */
      }
      if ((xIntersection < ballStartx && xIntersection > ballFinish.x ||
        xIntersection > ballStartx && xIntersection < ballFinish.x) &&
        (xIntersection < edgeStart.x && xIntersection > edgeFinish.x ||
          xIntersection > edgeStart.x && xIntersection < edgeFinish.x) 
           ){
            console.log("edge: Y = " + edgeSlope +  "X  + " + edgeIntercept);
            console.log("ball: Y = " + ballSlope +  "X  + " + ballIntercept);
            console.log("(" + xIntersection + ", " + yIntersection + ")");
            let deflectionForce = this.getDeflectionWall(edgeStart, edgeFinish, force)
            console.log("hit at " + xIntersection + ", " + yIntersection);;
            return {hit: true, forcex: deflectionForce.x, forcey: deflectionForce.y, locationx: xIntersection, locationy: yIntersection};
      }

      return deflection;
    }


    didShapeIntersect(lineStart, lineEnd){
      let shiftx = this.transform.position.x;
      let shifty = this.transform.position.y;

      
      var vertices = [];
      for (var i = 0; i < this.vertices.length; i++) {
        vertices.push( new Vector2(this.vertices[i].x + shiftx, this.vertices[i].y + shifty) );
      }
      for (var i = 0; i < vertices.length; i++) {
        var edgeFinish = vertices[0];
        if (i < vertices.length - 1){
          edgeFinish = vertices[i + 1];
        }

        if(this.didEdgeIntersect(lineStart, lineEnd, vertices[i], edgeFinish)){
          return true;
        }
        
        
      }
      return false;
    }

    didEdgeIntersect(lineStart, lineEnd, edgeStart, edgeFinish) {

      var deflection = false;
      var xIntersection = lineEnd.x;
      //console.log(lineStart.x + ", " + lineEnd.x + ", " + edgeFinish.x + ", " + edgeStart.x);
      if (edgeStart.x == edgeFinish.x){
        xIntersection = edgeFinish.x;
        
        if (xIntersection < lineStart.x && xIntersection > lineEnd.x ||
          xIntersection > lineStart.x && xIntersection < lineEnd.x){
            let ballSlope = (ballStarty - ballFinish.y) / (ballStartx - ballFinish.x);
            let yIntersection = ballStarty + ballSlope * Math.abs(ballStartx - xIntersection);
            console.log("Xhit at " + xIntersection + ", " + yIntersection);
            return true;
          }
      }

      if (lineEnd.x == lineStart.x){
        xIntersection = lineEnd.x;
        let edgeSlope = (edgeStart.y - edgeFinish.y) / (edgeStart.x - edgeFinish.x);
        let yIntersection = edgeStart.y + edgeSlope * Math.abs(edgeStart.x - xIntersection);

        if ((yIntersection < lineStart.y && yIntersection > lineEnd.y ||
          yIntersection > lineStart.y && yIntersection < lineEnd.y) && 
          (xIntersection < edgeFinish.x && xIntersection > edgeStart.x ||
            yIntersection > edgeFinish.x && yIntersection < edgeStart.x)){
            
            console.log("starty: " + lineStart.y + ", Endy: " + lineEnd.y);
            console.log("XXhit at " + xIntersection + ", " + yIntersection);
            return true;
          }
      }

      let edgeSlope = (edgeStart.y - edgeFinish.y) / (edgeStart.x - edgeFinish.x);
      let ballSlope = (lineStart.y - lineEnd.y) / (lineStart.x - lineEnd.x);
      let edgeIntercept = edgeStart.y - edgeSlope * edgeStart.x;
      let ballIntercept = lineStart.y - ballSlope * lineStart.x;
      //console.log("edge: Y = " + edgeSlope +  "X  + " + edgeIntercept);
      //console.log("aimer: Y = " + ballSlope +  "X  + " + ballIntercept);
      xIntersection = -(edgeIntercept - ballIntercept) / (edgeSlope - ballSlope);
      
      let yIntersection = ballSlope * xIntersection + ballIntercept;
      
      if ((xIntersection < lineStart.x && xIntersection > lineEnd.x ||
        xIntersection > lineStart.x && xIntersection < lineEnd.x) &&
        (xIntersection < edgeStart.x && xIntersection > edgeFinish.x ||
          xIntersection > edgeStart.x && xIntersection < edgeFinish.x) 
           ){
             /*
            console.log("edge: Y = " + edgeSlope +  "X  + " + edgeIntercept);
            console.log("aimer: Y = " + ballSlope +  "X  + " + ballIntercept);
            console.log("(" + xIntersection + ", " + yIntersection + ")");
            console.log("hit at " + xIntersection + ", " + yIntersection);;
            */
            return true;
      }

      return deflection;
    }

    containsPoint(point){
      let width = this.components[0].Geometry.width;
      let height = this.components[0].Geometry.height;
      let A = this.components[0].Geometry.coefficients.A;
      let B = this.components[0].Geometry.coefficients.B;
      let shiftx = this.transform.position.x;
      let shifty = this.transform.position.y;
      if(Math.abs(A) < .001){
        if (point.x < 0 + shiftx && point.x > -1 + shiftx && point.y > 0 + shifty && point.y < width + shifty){
          return true;
        }
        return false;
      }
      let corner1 = new Vector2(0 + shiftx, 0 + shifty);
      let corner2 = new Vector2(width * A + shiftx, width * B + shifty);
      let corner3 = new Vector2(width * A - (height * B) + shiftx, width * B + (height * A) + shifty);
      let corner4 = new Vector2(-(height * B) + shiftx, (height * A) + shifty);
      
      if(this.getSide(corner1, corner2, point) < 0){
        if(this.getSide(corner2, corner3, point) > 0){
          if(this.getSide(corner3, corner4, point) > 0){
            if(this.getSide(corner4, corner1, point) < 0){
              return true;
            }
          }
        }
      }
      return false;
    }

    getDeflection(point, force){
      let width = this.components[0].Geometry.width;
      let A = this.components[0].Geometry.coefficients.A;
      let B = this.components[0].Geometry.coefficients.B;
      let shiftx = this.transform.position.x;
      let shifty = this.transform.position.y;
      
      let corner1 = new Vector2(0 + shiftx, 0 + shifty);
      let corner2 = new Vector2(width * A + shiftx, width * B + shifty);
      let corner3 = new Vector2(width * A - B + shiftx, width * B + A + shifty);
      let corner4 = new Vector2(-B + shiftx, A + shifty);
      
      if(this.getSide(corner1, corner2, point) < 0){
        if(this.getSide(corner2, corner3, point) > 0){
          if(this.getSide(corner3, corner4, point) > 0){
            console.log("4: " + corner4 + " , " + corner1 + " p " + point);
            return this.getDeflectionWall(corner4, corner1, force);
          } else{
            console.log("3: " + corner3 + " , " + corner4 + " p " + point);
            return this.getDeflectionWall(corner3, corner4, force);
          }
        } else {
          console.log("2: " + corner2 + " , " + corner3 + " p " + point);
          return this.getDeflectionWall(corner2, corner3, force);
        }
      }
      console.log("1: " + corner1 + " , " + corner2 + " p " + point);
      return this.getDeflectionWall(corner1, corner2, force);
    }
    
    getSide(p, q, r){
      if (p.x == q.x){
        
          return r.x - p.x;
        
      }
      let slope = (p.y - q.y) / (p.x - q.x);
      let offset = r.x - p.x;
      let lineHieght = offset * slope + p.y;
      return Math.sign(lineHieght - r.y);
    }

    getDeflectionWall(p, q, force){
      console.log("ForceIn: " + force.x + ", " + force.y)
      var wallAngle = 3.1416 / 2;
      if( p.x != q.x){
        console.log("rise: " + (p.y - q.y) + " run: " + (p.x - q.x))
        let slope = (p.y - q.y) / (p.x - q.x);
        wallAngle = Math.atan(slope);
      }

      
      console.log("wallAngle: " + wallAngle / 3.1415  * 180);
      var forceAngle = Math.atan(force.y / force.x);
      //console.log("forceAngle: " + forceAngle / 3.1415  * 180);
      if(force.x < 0){
        forceAngle += 3.14159;
      }
      console.log("forceAngle: " + forceAngle / 3.1415  * 180);
      let interceptAngle = forceAngle - wallAngle;
      //console.log(forceAngle + " - " + wallAngle + " = " + interceptAngle);
      let reflectionAngle = wallAngle - interceptAngle;
      //console.log(wallAngle + " - " + interceptAngle + " = " + reflectionAngle);
      console.log("reflectionAngle: " + reflectionAngle / 3.1415 * 180)
      let YXratio = Math.tan(reflectionAngle);
      console.log("YXratio: " + YXratio)
      let magnitude = Math.abs(force.x) + Math.abs(force.y);
      var newx = magnitude / (Math.abs(YXratio) + 1);
      //console.log
      if(reflectionAngle < -1.5708 && reflectionAngle > -4.712 || reflectionAngle > 1.5708){
        newx *= -1;
      }
      let newForce = new Vector2(newx, YXratio * newx);
      console.log("ForceOut:" + newForce.x + ", " + newForce.y)
      return new Vector2(newx, YXratio * newx);
    }


  }