class WallConnect extends GameObject {
    constructor(){
      super();    
      this.radius = .2;
  
      var myGeometry = new Circle(this.radius);
      var myGeometryComponent = new GeometryComponent(myGeometry);
      this.components.push(myGeometryComponent);
  
      var myRenderer = new GeometryRendererComponent("blue", myGeometry);
      this.components.push(myRenderer);
      this.renderer = myRenderer;

    }
    
    
  } 