function updateStateHandler() {
    if (state == TITLE_STATE) {
      stateHandler = titleStateHandler;
    } else if (state == LOAD_STATE) {
      stateHandler = loadStateHandler;

      var canvas = document.getElementById("stretchy");
        canvas.style.marginTop = "50px";
        canvas.style.marginBottom = "200px";
        canvas.style.marginLeft = "200px";
        canvas.style.marginRight = "200px";
        var canvas = document.getElementById("app");
        canvas.style.visibility = "visible";
        canvas = document.getElementById("canv");
        canvas.width = canvas.offsetWidth;
        canvas.height = canvas.offsetHeight;
        width = canvas.width;
        height = canvas.height;


    } else if (state == DESIGN_STATE) {
      stateHandler = designStateHandler;
    } else if (state == RUN_STATE) {
      stateHandler = runStateHandler;
      var canvas = document.getElementById("stretchy");
        canvas.style.margin = "0px";
        var canvas = document.getElementById("app");
        canvas.style.visibility = "hidden";
        canvas = document.getElementById("canv");
        canvas.width = canvas.offsetWidth;
        canvas.height = canvas.offsetHeight;
        width = canvas.width;
        height = canvas.height;
        console.log("new size: " + width + "x" + height);

    } else if (state == END_STATE) {
      stateHandler = endStateHandler;
    } else if (state == BOARDER_CREATION_STATE) {
      stateHandler = boarderStateHandler;
    }
    
    console.log(state);
  
    
    stateHandler.start();
  }