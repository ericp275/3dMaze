var titleStateHandler = {
    start() {
      updateListeners.push(this);
    },
    eventPump(event) {
      switch (event.name) {
        case "click":
          this.nextScene();
          break;
        case "timer":
          this.update();
          this.render();
          break;
      }
    },
    nextScene() {
      state = LOAD_STATE;
      updateListeners.splice(updateListeners.indexOf(this), 1);
      updateStateHandler();
    },
    update() {
      //This is where I update my model. I don't do any rendering here.
  
      
    },
    bouncemod( number, modulo){
      flip = 1;
      while(number > modulo){
        number -= modulo;
        flip *= -1;
      }
      result = modulo + flip * number;
      if (result > modulo){
        result -= modulo;
      }
      return result;
    },
    render() {   
      //This is where I render. I don't update my model here.
      ctx.fillStyle = "white";
      ctx.fillRect(0, 0, width, height);
  
      var rDimensions = positionGUI(width, height, .25, 20, .25)
  
      ctx.fillStyle = "rgba(255, 255, 255, .5)"
  
      ctx.fillRect(rDimensions.x,
        rDimensions.y,
        rDimensions.width,
        rDimensions.height);
  
  
      ctx.fillStyle = "black";
      ctx.font = "20px Arial";
  
      let string = "Click to Start";
  
      ctx.fillText(string, rDimensions.x + rDimensions.width / 2 - ctx.measureText(string).width / 2, rDimensions.y + 20);


      var i = 0;
      for (i = 0; i < 90; i += 1){
        let red = this.bouncemod(i * 9, 255);
        let green = this.bouncemod(i * 11, 255);
        let blue = this.bouncemod(i * 17, 255);
        ctx.fillStyle = "rgba(" + red + ", " + green + ", " + blue + ", 1)"
        ctx.fillRect(i * 5 - 100 + width / 2 - 150, height / 2, 5, 20);
      }
      /*
      for (i = 0; i < 51; i += 3){
        let red = (255 - i * 5);
        let green = 255;
        let blue = i * 5;
        ctx.fillStyle = "rgba(" + red + ", " + green + ", " + blue + ", 1)"
        ctx.fillRect(i - 100 + width / 2 - 150 + 85, height / 2, 5, 20);
      }
      for (i = 0; i < 51; i += 3){
        let red = i * 5;
        let green = (255 - i * 5);
        let blue = (255 - i * 5);
        ctx.fillStyle = "rgba(" + red + ", " + green + ", " + blue + ", 1)"
        ctx.fillRect(i - 100 + width / 2 - 150 + 170, height / 2, 5, 20);
      }
      for (i = 0; i < 51; i += 3){
        let red = (255 - i * 5);
        let green = 0;
        let blue = i * 5;
        ctx.fillStyle = "rgba(" + red + ", " + green + ", " + blue + ", 1)"
        ctx.fillRect(i - 100 + width / 2 - 150 + 255, height / 2, 5, 20);
      }
      for (i = 0; i < 51; i += 3){
        let red = i * 5;
        let green = i * 5;
        let blue = 255;
        ctx.fillStyle = "rgba(" + red + ", " + green + ", " + blue + ", 1)"
        ctx.fillRect(i - 100 + width / 2 - 150 + 340, height / 2, 5, 20);
      }
  */
      
    }
  };