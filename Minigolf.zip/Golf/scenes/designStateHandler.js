var designStateHandler = {
    start() {
      updateListeners.push(this);
      cameraZoom = 50;
      this.firstClick = true;
      this.connected = false;
      this.wallStarted = false;
      this.wallStart = new Vector2();
      this.wallEnd = new Vector2();
      this.connector = new WallConnect();
      this.connector.transform.position.x = 500;
      this.connector.transform.position.y = 500;
      this.connector.components[1].visible = false;
      this.links = 1;
      this.adder = new WallConnect();
      this.adder.transform.position.x = 500;
      this.adder.transform.position.y = 500;
      this.adder.components[1].color = "red";
      this.mode = "Wall";
      this.terrain = "Solid";

      if(!initialized){

      this.otherSquare = new Bad();
      this.otherSquare.transform.position.x = -1;
      this.otherSquare.transform.position.y = -1;
  

      this.hole = new Hole();
      this.hole.transform.position.x = 3;
      this.hole.transform.position.y = 4;
  
      
      

      this.wall1 = new Boarder(90, 20, this.terrain);
      this.wall2 = new Boarder(0, 20, this.terrain);
      this.wall3 = new Boarder(90, 20, this.terrain);
      this.wall4 = new Boarder(0, 20, this.terrain);
      //var point = getAlteredCoordinates(width, height);
      this.wall1.transform.position.x = -10;
      this.wall1.transform.position.y = -10;
      this.wall2.transform.position.x = -9;
      this.wall2.transform.position.y = -10;
      this.wall3.transform.position.x = -10;
      this.wall3.transform.position.y = 9;
      this.wall4.transform.position.x = 10;
      this.wall4.transform.position.y = -10;
  
      hierarchy.push(this.hole);
      hierarchy.push(this.otherSquare);
      
      hierarchy.push(this.wall1);
      hierarchy.push(this.wall2);
      hierarchy.push(this.wall3);
      hierarchy.push(this.wall4);
      
      } else {
        this.otherSquare = hierarchy[1];
        this.otherSquare.transform.position.x = -1;
        this.otherSquare.transform.position.y = -1;
      }
      initialized = true;
    
      this.render();


    },
    eventPump(event) {
      switch (event.name) {      
        case "timer":
          this.update();
          this.render();
          break;
        case "changeMode":
          this.firstClick = true;
          buildMode = event.buildMode;
          this.mode = buildMode;
          if( this.mode == "Sand"){
            this.mode = "Wall";
            this.terrain = "Sand";
          } else if (this.mode == "Water"){
            this.mode = "Wall";
            this.terrain = "Water";
          } else {
            this.terrain = "Solid";
          }
          document.getElementById("modeLabel").innerHTML = buildMode;
          console.log(event);
          
          console.log("now building " + this.mode);
          break;
        case "click":
        //console.log(this.getAlteredCoordinates(event.location.x, event.location.y));
          switch(this.mode){
            case "Boundary":
              if(this.getDistance(this.getAlteredCoordinates(event.location.x, event.location.y), this.connector.transform.position) < .25 && this.connector.components[1].visible){
                  console.log("Update Hierarchy")
                  let newHierarchy = [];
                  index = 0;
                  for (var i = 0; i < hierarchy.length; i++) {
                    var gameObject = hierarchy[i];
                    if(gameObject instanceof Boarder){
                      if(gameObject.active){
                        console.log(i);
                        newHierarchy[index] = hierarchy[i];
                        index++;
                      }
                    } else {
                      console.log(i);
                      newHierarchy[index] = hierarchy[i];
                      index++;
                    }
                  }
                  hierarchy = newHierarchy;
                  this.firstClick = true;
                  this.connector.components[1].visible = false;
              } else {
                this.wallStart = this.getAlteredCoordinates(event.location.x, event.location.y);
                console.log("firstClick:" + this.wallStart.x + ", " + this.wallStart.y);
                newPoint = this.getAlteredCoordinates(event.location.x, event.location.y);
                wall = this.getWall(newPoint);
                //this.connector.transform.position.x = this.wallStart.x;
                //this.connector.transform.position.y = this.wallStart.y;

                if(this.firstClick){
                for (var i = 0; i < hierarchy.length; i++) {
                  var gameObject = hierarchy[i];
          
                  if(gameObject instanceof Boarder){
                      gameObject.makeInactive();
                  }  
                }
                this.connector = new WallConnect();
                this.connector.transform.position.x = this.wallStart.x;
                this.connector.transform.position.y = this.wallStart.y;
                this.connector.components[1].visible = true;
                hierarchy.push(this.connector);
                this.firstClick = false;
                } 
                hierarchy.push(wall);
              }
              
              break;
            case "Wall":
              this.HandleClickWall(event);
              break;
            case "Obstacle":
              //this.HandleClickObstacle(event);
              //this.HandleClickPrefab(event);
              
              let point = this.getAlteredCoordinates(event.location.x, event.location.y);
              let radius = this.getClosestIntersection(point);
              let vertices = [];
              vertices.push( new Vector2(.5, - radius) );
              vertices.push( new Vector2(.5, radius) );
              vertices.push( new Vector2(-.5, radius ));
              vertices.push( new Vector2(-.5, -radius ));
              let mark = new Rotator(0, radius, "Solid");
              mark.transform.position = point;
              hierarchy.push(mark);
              
              break;
            case "Ball":
              this.otherSquare.transform.position = this.getAlteredCoordinates(event.location.x, event.location.y);
              break;
            case "Hole":
              this.hole.transform.position = this.getAlteredCoordinates(event.location.x, event.location.y);
              break;
          }
            
          break;
        case "mousemove":

        switch(this.mode){
          case "Boundary":
            var lastWall = hierarchy.length - 1;
            if(hierarchy[hierarchy.length - 1] instanceof WallConnect){
              lastWall -= 1;
            }
            if(!this.firstClick){
              newPoint = this.getAlteredCoordinates(event.location.x, event.location.y);
              hierarchy[lastWall] = this.getWall(newPoint);
            }
            break;
          case "Wall":
          if(!this.firstClick){
            newPoint = this.getAlteredCoordinates(event.location.x, event.location.y);
            hierarchy[hierarchy.length - 1] = this.getWall(newPoint);
          }
            break;
          case "Obstacle":
          /*
            if(!this.firstClick){
              newPoint = this.getAlteredCoordinates(event.location.x, event.location.y);
              hierarchy.pop();
              this.pushEllipse(newPoint);
            }
            */
           if(!this.firstClick){
            newPoint = this.getAlteredCoordinates(event.location.x, event.location.y);
            hierarchy.pop();
            this.pushPrefab(newPoint);
          }
            break;
        }
          
          break;
        case "mousewheel":
          if(event.delta < 0){
            cameraZoom *= 1.05;
          } else {
            cameraZoom /= 1.05;
          }
          //console.log(cameraZoom);
          break;
        case "startGame":
            this.nextScene();
          break;
        case "boarderToggle":
            this.createBoarders();
            break;
        case "resize":
        canvas = document.getElementById("canv");
        canvas.width = canvas.offsetWidth;
        canvas.height = canvas.offsetHeight;
        width = canvas.width;
        height = canvas.height;
        console.log("new size: " + width + "x" + height);

        break;
      }
    },

    HandleClickObstacle(event){
      if(this.firstClick){
                this.wallStart = this.getAlteredCoordinates(event.location.x, event.location.y);
                console.log("firstClick:" + this.wallStart.x + ", " + this.wallStart.y);
                newPoint = this.getAlteredCoordinates(event.location.x + .01, event.location.y);
                this.pushEllipse(newPoint);
                this.firstClick = false;
      } else {
              newPoint = this.getAlteredCoordinates(event.location.x, event.location.y);
              hierarchy.pop();
              var ellipse = this.pushEllipse(newPoint);
              this.firstClick = true;
              let shiftx = ellipse.transform.position.x;
              let shifty = ellipse.transform.position.y;
              /*
              for(var i = 0; i < 12; i++){
                var mark = new Marker();
                mark.transform.position.x = ellipse.vertices[i].x + shiftx;
                mark.transform.position.y = ellipse.vertices[i].y + shifty;
                hierarchy.push(mark);
              }
              */


      }
    },

    HandleClickPrefab(event){
      if(this.firstClick){
                this.wallStart = this.getAlteredCoordinates(event.location.x, event.location.y);
                console.log("firstClick:" + this.wallStart.x + ", " + this.wallStart.y);
                newPoint = this.getAlteredCoordinates(event.location.x + .01, event.location.y);
                this.pushEllipse(newPoint);
                this.firstClick = false;
      } else {
              newPoint = this.getAlteredCoordinates(event.location.x, event.location.y);
              hierarchy.pop();
              var ellipse = this.pushPrefab(newPoint);
              this.firstClick = true;
              let shiftx = ellipse.transform.position.x;
              let shifty = ellipse.transform.position.y;
              /*
              for(var i = 0; i < ellipse.vertices.length; i++){
                var mark = new Marker();
                mark.transform.position.x = ellipse.vertices[i].x + shiftx;
                mark.transform.position.y = ellipse.vertices[i].y + shifty;
                hierarchy.push(mark);
              }
              */


      }
    },

    pushEllipse(newPoint){
      let slope = Math.atan((newPoint.y - this.wallStart.y) / (newPoint.x - this.wallStart.x));
      //console.log("slope: " + slope);
      var radians = slope;
      if(slope < 0){
        radians = 3.14159 + slope;
      } 
      if(newPoint.y > this.wallStart.y){
        radians += 3.14159;
      }
      var dist = this.getDistance(newPoint, this.wallStart);
      var midpoint = {x: (newPoint.x + this.wallStart.x) / 2, y: (newPoint.y + this.wallStart.y) / 2};
      wall = new EllipseWall(dist / 2 + .5, radians / 3.14159 * 180, 2.5);
      wall.transform.position = midpoint;
      //console.log(wall.transform.position);
        
      hierarchy.push(wall);
      return wall;
    },

    pushPrefab(newPoint){
      let slope = Math.atan((newPoint.y - this.wallStart.y) / (newPoint.x - this.wallStart.x));
      //console.log("slope: " + slope);
      var radians = slope;
      if(slope < 0){
        radians = 3.14159 + slope;
      } 
      if(newPoint.y > this.wallStart.y){
        radians += 3.14159;
      }
      var dist = this.getDistance(newPoint, this.wallStart);
      //var midpoint = {x: (newPoint.x + this.wallStart.x) / 2, y: (newPoint.y + this.wallStart.y) / 2};
      let object = new PrefabObstacle(dist, radians, "boat");
      object.transform.position = this.wallStart;
      //console.log(wall.transform.position);
        
      hierarchy.push(object);
      return object;
    },


    HandleClickWall(event){
      this.connector.components[1].visible = false;
            
            if(this.firstClick){
                this.wallStart = this.getAlteredCoordinates(event.location.x, event.location.y);
               // console.log("firstClick:" + this.wallStart.x + ", " + this.wallStart.y);
                newPoint = this.getAlteredCoordinates(event.location.x, event.location.y);
                wall = this.getWall(newPoint);
                if(this.getDistance(this.getAlteredCoordinates(event.location.x, event.location.y), this.adder.transform.position) < .25){
                  this.links += 1;
                //  console.log("links: " + this.links);
                  if(this.links > 2){
                    this.connected = true;
                    this.connector.components[1].visible = true;
                  }
                } else {
                  this.links = 1;
                //  console.log("links: " + this.links);
                  this.connector.transform.position.x = this.wallStart.x;
                  this.connector.transform.position.y = this.wallStart.y;
                  hierarchy.push(this.connector);
                  this.connected = false;
                  this.adder.components[1].visible = false;
                }
                hierarchy.push(wall);
                this.firstClick = false;
              } else if (this.getDistance(this.getAlteredCoordinates(event.location.x, event.location.y), this.connector.transform.position) < .25){
                this.makePolygon()
                this.connected = false;
                this.firstClick = true;
            } else {
              this.wallEnd = this.getAlteredCoordinates(event.location.x, event.location.y);
              this.adder.transform.position.x = this.wallEnd.x;
              this.adder.transform.position.y = this.wallEnd.y;
              hierarchy.push(this.adder);
              this.firstClick = true;
              this.wallStarted = true;
              this.connected = false;
              this.adder.components[1].visible = true;
            }
    },


    getClosestIntersection(point){
      var minDist = 20;
      for(var i = 0; i < hierarchy.length; i++){
        gameObject = hierarchy[i];
        if(gameObject instanceof Obstacle){
          dist = gameObject.getMinDistance(point);
          console.log("distance to object " + i + " = " + dist);
          if(dist < minDist){
            minDist = dist;
          }
        }
      }
      console.log("MinDist: " + minDist);
      return minDist;
    },

    getDistance(event, point){
      return Math.sqrt((event.x - point.x) * (event.x - point.x) + (event.y - point.y) * (event.y - point.y));
    },

    makePolygon(){
      console.log("making Polygon");
      console.log(hierarchy);
      let vertices = [];
      while(this.links > 0){
        let wall = hierarchy.pop();//hierarchy[hierarchy.length - 1];
        console.log(wall);
        if(wall instanceof Good){
          let point = wall.start;
          vertices.push(point);
          this.links -= 1;
        }
      }
      let realVerts = this.findVerticies(vertices);
      let convexObstacle = new ConvexObstacle(realVerts, vertices, this.terrain);
      console.log(convexObstacle);
      this.clean();
      hierarchy.push(convexObstacle);
      console.log(hierarchy);
    },

    findVerticies(vertices){
      //vertices.reverse();
      var sumAngles = 0;
      newVerts = [];
      let last = vertices.length - 1;
      console.log("using vertices:");
      console.log(vertices);
      while(true){
      let firstSlope = Math.atan((vertices[last].y - vertices[0].y) / (vertices[last].x - vertices[0].x));
      console.log("First slope: " + firstSlope);
      var firstRadians = firstSlope;
      var lastConvexPoint = vertices[last];
      if(firstSlope < 0){
        firstRadians = 3.14159 + firstSlope;
      } 
      if(vertices[last].y > vertices[0].y){
        firstRadians += 3.14159;
      }
      for(var i = 0; i < vertices.length; i++){
        var vertice = vertices[i];
        var nextVertice = vertices[0];
        if (i < vertices.length - 1){
          nextVertice = vertices[i + 1];
        }
        let slope = Math.atan((vertice.y - nextVertice.y) / (vertice.x - nextVertice.x));
        console.log("slope: " + slope);
        var radians = slope;
        if(slope < 0){
          radians = 3.14159 + slope;
        } 
        if(vertice.y > nextVertice.y){
          radians += 3.14159;
        }
        
        var opp = radians - 3.14159;
        if(opp < 0){
          opp += 3.14159 * 2;
        }
        var difference = firstRadians - opp;
        if(opp > firstRadians) {difference += 3.14159 * 2}
        let midpoint = difference / 2 + opp;
        //var ellipse = new Marker();
        console.log(firstRadians + "-->" + opp + " ==>" + midpoint);
        //if(midpoint < 3.14159 && midpoint > )
        //ellipse.transform.position.y = vertice.y + .25 * Math.sin(midpoint);
        //ellipse.transform.position.x = vertice.x + .25 * Math.cos(midpoint);
        //hierarchy.push(ellipse);
        newVerts.push({x: vertice.x + .5 * Math.cos(midpoint), y: vertice.y + .5 * Math.sin(midpoint)})

        var angle = radians - firstRadians;
        if(radians < firstRadians) {angle += 3.14159 * 2}
        sumAngles += angle;

        firstRadians = radians;
        lastConvexPoint = vertice;
      //check concavity
        

      }

      if (sumAngles > vertices.length * 3.14159){
        sumAngles = 0;
        for (var point = 0; point < vertices.length; point++){
          newVerts.pop();
        }
        vertices.reverse();
      } else {
        break;
      }

      }
      return newVerts;
    },

    getWall(newPoint){
      let rise = newPoint.y - this.wallStart.y;
      let run = newPoint.x - this.wallStart.x;
      let slope = rise / run;
      //console.log("Slope: " + slope);
      let angle = Math.atan(slope) / 3.14159 * 180;
      //console.log("Angle: " + angle);
      if(newPoint.x < this.wallStart.x){
        angle += 180;

      } else if (angle < 0){
        angle = 360 + angle;
      }

      //console.log("360Angle: " + angle);
      var alteredAngle = 0;

      if(angle > 0 && angle <= 90){
        alteredAngle = 90 - angle;
      } else if (angle > 90 && angle <= 270){
        alteredAngle = 270 - angle;
      } else {
        alteredAngle =  450 - angle;
      }

      var shiftedAngle = angle;
      if (angle < 0){
          shiftedAngle += 180;
      }
      //console.log("CorrectedAngle: " + alteredAngle);
      let distance = Math.sqrt(rise * rise + run * run) + .5;
      //console.log("Distance: " + distance);
      let wall = new Good(alteredAngle, distance, this.terrain);
      if (this.mode == "Boundary"){
        wall = new Boarder(alteredAngle, distance);
      }
      
      let A = wall.components[1].geometry.coefficients.A;
      let B = wall.components[1].geometry.coefficients.B;
      var xshift = 0;
      var yshift = 0;
      if (90 < angle && angle < 180){
        xshift = -A / 2;
        yshift = -B / 2;
      } else if (180 <= angle && angle < 270){
        xshift = B / 2;
        yshift = -A / 2;
      }

      if(shiftedAngle < 180){
          wall.transform.position.x = this.wallStart.x - .25 * A + .25 * B + xshift;
          wall.transform.position.y = this.wallStart.y - .25 * A - .25 * B + yshift;
      } else {
          wall.transform.position.x = newPoint.x  - .25 * A + .25 * B + xshift;
          wall.transform.position.y = newPoint.y  - .25 * A - .25 * B + yshift;
      }
      wall.start = newPoint;
      return wall;
    },

    clean(){
      for(var i = hierarchy.length - 1; i >= 0; i--){
        if(hierarchy[i] instanceof WallConnect){
          hierarchy[i].components[1].visible = false;
        }
      }
    },

    nextScene() {
      this.clean();
      state = RUN_STATE;
      updateListeners.splice(updateListeners.indexOf(this), 1);
      updateStateHandler();
    },

    createBoarders() {
      state = BOARDER_CREATION_STATE;
      updateListeners.splice(updateListeners.indexOf(this), 1);
      updateStateHandler();
    },

    getAlteredCoordinates(x, y){
        x -= width / 2 + cameraPan.x;
        y -= height / 2 + cameraPan.y;
        x /= cameraZoom;
        y /= cameraZoom;
        y = -y;
        return {x: x, y: y};
      },

    update() {
      //This is where I update my model. I don't do any rendering here.
      if (keys["ArrowLeft"]) {
        cameraPan.x += 5; /// speed is in units/s * s
      }
      if (keys["ArrowRight"]) {
        cameraPan.x -= 5; /// speed is in units/s * s
      }
  
      if (keys["ArrowUp"]) {
        cameraPan.y += 5; /// speed is in units/s * s
      }
      if (keys["ArrowDown"]) {
        cameraPan.y -= 5; /// speed is in units/s * s
      }
    },


    render() {
      //This is where I render. I don't update my model here.   
  
      ctx.fillStyle = "green";
      ctx.fillRect(0, 0, width, height);

      ctx.save(); {
        //Camera transformations
        ctx.translate(width / 2, height / 2);
        ctx.translate(cameraPan.x, cameraPan.y);
        ctx.scale(cameraZoom, cameraZoom);
        ctx.save(); {
          //World transformation
          ctx.scale(1, -1);
  
  
          ctx.save(); {
  
  
            for (var i = 0; i < hierarchy.length; i++) {
              var gameObject = hierarchy[i];
  
              ctx.save(); {
                ctx.translate(gameObject.transform.position.x, gameObject.transform.position.y);
                ctx.scale(gameObject.transform.scale.x, gameObject.transform.scale.y);
  
                if (typeof gameObject.render === "function")
                  gameObject.render(ctx);
              }
              ctx.restore();
  
            }
          }
          ctx.restore();
        }
        ctx.restore();
      }
      ctx.restore();
      

  
      var rDimensions = positionGUI(width, height, .25, 20, .25)
  
      ctx.fillStyle = "rgba(255, 255, 255, .5)"
  
      ctx.fillRect(rDimensions.x,
        rDimensions.y,
        rDimensions.width,
        rDimensions.height);
  
  
      ctx.fillStyle = "black";
      ctx.font = "20px Arial";
  
      let string = "Design your Mini-Golf Course!";
  
      ctx.fillText(string, rDimensions.x + rDimensions.width / 2 - ctx.measureText(string).width / 2, rDimensions.y + 20);
    }
  };