var setupStateHandler = {
    start() {
      updateListeners.push(this);
      this.cameraZoom = 50;
      this.firstClick = true;
      this.wallStart = new Vector2();
      this.color = "white";

      for (var i = 0; i < hierarchy.length; i++) {
        var gameObject = hierarchy[i];

        if(gameObject instanceof Boarder){
            gameObject.makeInactive();
        }
          
    }
        

    this.ballSliderX = 1;
      this.render();


    },
    eventPump(event) {
      switch (event.name) {      
        case "timer":
          this.update();
          this.render();
          break;
        case "click":
            let clickPoint = this.getAlteredCoordinates(event.location.x, event.location.y);
            if(clickPoint.x < 3 && clickPoint.x > -3 && clickPoint.y < 0 && clickPoint.y > -1.2){
                this.nextScene();
            }
            if(clickPoint.x < 2.5 && clickPoint.x > -2.5 && clickPoint.y < -3.9 && clickPoint.y > -4.5){
                this.ballSliderX = clickPoint.x;
            }
          break;
        case "mousemove":
            let point = this.getAlteredCoordinates(event.location.x, event.location.y);
            console.log( "x: " + point.x + ", y: " + point.y);
          break;
        case "mousewheel":
          if(event.delta < 0){
            this.cameraZoom *= 1.05;
          } else {
            this.cameraZoom /= 1.05;
          }
          console.log(this.cameraZoom);
          break;
        case "startGame":
            this.nextScene();
          break;
        case "boarderToggle":
            this.exitBoarderState();
            break;
      }
    },


    nextScene() {
      state = LOAD_STATE;
      updateListeners.splice(updateListeners.indexOf(this), 1);
      updateStateHandler();
    },

    getAlteredCoordinates(x, y){
        x -= width / 2 + cameraPan.x;
        y -= height / 2 + cameraPan.y;
        x /= cameraZoom;
        y /= cameraZoom;
        y = -y;
        return {x: x, y: y};
      },


    update() {
      //This is where I update my model. I don't do any rendering here.
      
    },


    render() {
      //This is where I render. I don't update my model here.   
  
      ctx.fillStyle = "green";
      ctx.fillRect(0, 0, width, height);

      ctx.save(); {
        //Camera transformations
        ctx.translate(width / 2, height / 2);
        ctx.scale(this.cameraZoom, this.cameraZoom);
  
        ctx.save(); {
          //World transformation
          ctx.scale(1, -1);
  
          ctx.fillStyle = this.color;
  
          ctx.beginPath();
          ctx.ellipse(0, 0, 2, 2, 0, 0, Math.PI * 2);
          ctx.fill();
        
          ctx.save(); {
              ctx.fillStyle = "lightblue";
          ctx.fillRect(-2.5, -1, 5, 1);
          ctx.save(); {
            ctx.fillStyle = "black";
            ctx.scale(3 / this.cameraZoom, -2 / this.cameraZoom);
            ctx.fillText("Start", -(.45) * this.cameraZoom, .35 * this.cameraZoom);
          }
          ctx.restore();

          let image = document.getElementById("colorScale");
          ctx.drawImage(image, -2, -3.5, 4, .3);
          ctx.fillStyle = "black";
          ctx.fillRect(this.ballSliderX, -3.7, .2, .6);
            }
            ctx.restore();
        }
        ctx.restore();
      }
      ctx.restore();



  
      var rDimensions = positionGUI(width, height, .25, 20, .25)
  
      ctx.fillStyle = "rgba(255, 255, 255, .5)"
  
      ctx.fillRect(rDimensions.x,
        rDimensions.y,
        rDimensions.width,
        rDimensions.height);
  
  
      ctx.fillStyle = "black";
      ctx.font = "20px Arial";
  
      let string = "Game Settings";
  
      ctx.fillText(string, rDimensions.x + rDimensions.width / 2 - ctx.measureText(string).width / 2, rDimensions.y + 20);
    }
  };