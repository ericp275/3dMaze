var boarderStateHandler = {
    start() {
      updateListeners.push(this);
      this.cameraZoom = 50;
      this.firstClick = true;
      this.wallStart = new Vector2();

      for (var i = 0; i < hierarchy.length; i++) {
        var gameObject = hierarchy[i];

        if(gameObject instanceof Boarder){
            gameObject.makeInactive();
        }
          
    }
        


      this.render();


    },
    eventPump(event) {
      switch (event.name) {      
        case "timer":
          this.update();
          this.render();
          break;
        case "click":
            
            this.wallStart = this.getAlteredCoordinates(event.location.x, event.location.y);
            console.log("firstClick:" + this.wallStart.x + ", " + this.wallStart.y);
            newPoint = this.getAlteredCoordinates(event.location.x, event.location.y);
            wall = this.getWall(newPoint);
            hierarchy.push(wall);
            if(this.firstClick){
                let connector = new WallConnect();
                connector.transform.position.x = this.wallStart.x;
                connector.transform.position.y = this.wallStart.y;
                hierarchy.push(connector);
            }
            this.firstClick = false;
            
          break;
        case "mousemove":
            var lastWall = hierarchy.length - 1;
          if(hierarchy[hierarchy.length - 1] instanceof WallConnect){
            lastWall -= 1;
          }
          if(!this.firstClick){
            newPoint = this.getAlteredCoordinates(event.location.x, event.location.y);
            hierarchy[lastWall] = this.getWall(newPoint);
          }
          break;
        case "mousewheel":
          if(event.delta < 0){
            this.cameraZoom *= 1.05;
          } else {
            this.cameraZoom /= 1.05;
          }
          console.log(this.cameraZoom);
          break;
        case "startGame":
            this.nextScene();
          break;
        case "boarderToggle":
            this.exitBoarderState();
            break;
      }
    },

    getWall(newPoint){
      let rise = newPoint.y - this.wallStart.y;
      let run = newPoint.x - this.wallStart.x;
      let slope = rise / run;
      //console.log("Slope: " + slope);
      let angle = Math.atan(slope) / 3.14159 * 180;
      //console.log("Angle: " + angle);
      if(newPoint.x < this.wallStart.x){
        angle += 180;

      } else if (angle < 0){
        angle = 360 + angle;
      }

      //console.log("360Angle: " + angle);
      var alteredAngle = 0;

      if(angle > 0 && angle <= 90){
        alteredAngle = 90 - angle;
      } else if (angle > 90 && angle <= 270){
        alteredAngle = 270 - angle;
      } else {
        alteredAngle =  450 - angle;
      }

      var shiftedAngle = angle;
      if (angle < 0){
          shiftedAngle += 180;
      }
      //console.log("CorrectedAngle: " + alteredAngle);
      let distance = Math.sqrt(rise * rise + run * run) + .5;
      //console.log("Distance: " + distance);
      let wall = new Good(alteredAngle, distance);
      
      let A = wall.components[1].geometry.coefficients.A;
      let B = wall.components[1].geometry.coefficients.B;
      var xshift = 0;
      var yshift = 0;
      if (90 < angle && angle < 180){
        xshift = -A / 2;
        yshift = -B / 2;
      } else if (180 <= angle && angle < 270){
        xshift = B / 2;
        yshift = -A / 2;
      }

      if(shiftedAngle < 180){
          wall.transform.position.x = this.wallStart.x - .25 * A + .25 * B + xshift;
          wall.transform.position.y = this.wallStart.y - .25 * A - .25 * B + yshift;
      } else {
          wall.transform.position.x = newPoint.x  - .25 * A + .25 * B + xshift;
          wall.transform.position.y = newPoint.y  - .25 * A - .25 * B + yshift;
      }
      return wall;
    },


    nextScene() {
      state = RUN_STATE;
      updateListeners.splice(updateListeners.indexOf(this), 1);
      updateStateHandler();
    },

    exitBoarderState() {
      state = DESIGN_STATE;
      updateListeners.splice(updateListeners.indexOf(this), 1);
      updateStateHandler();
    },

    getAlteredCoordinates(x, y){
        x -= width / 2;
        y -= height / 2;
        x /= this.cameraZoom;
        y /= this.cameraZoom;
        y = -y;
        return {x: x, y: y};
      },

    update() {
      //This is where I update my model. I don't do any rendering here.
      
    },


    render() {
      //This is where I render. I don't update my model here.   
  
      ctx.fillStyle = "green";
      ctx.fillRect(0, 0, width, height);

      ctx.save(); {
        //Camera transformations
        ctx.translate(width / 2, height / 2);
        ctx.scale(this.cameraZoom, this.cameraZoom);
  
        ctx.save(); {
          //World transformation
          ctx.scale(1, -1);
  
  
          ctx.save(); {
  
  
            for (var i = 0; i < hierarchy.length; i++) {
              var gameObject = hierarchy[i];
  
              ctx.save(); {
                ctx.translate(gameObject.transform.position.x, gameObject.transform.position.y);
                ctx.scale(gameObject.transform.scale.x, gameObject.transform.scale.y);
  
                if (typeof gameObject.render === "function")
                  gameObject.render(ctx);
              }
              ctx.restore();
  
            }
          }
          ctx.restore();
        }
        ctx.restore();
      }
      ctx.restore();
      

  
      var rDimensions = positionGUI(width, height, .25, 20, .25)
  
      ctx.fillStyle = "rgba(255, 255, 255, .5)"
  
      ctx.fillRect(rDimensions.x,
        rDimensions.y,
        rDimensions.width,
        rDimensions.height);
  
  
      ctx.fillStyle = "black";
      ctx.font = "20px Arial";
  
      let string = "Design your Mini-Golf Course!";
  
      ctx.fillText(string, rDimensions.x + rDimensions.width / 2 - ctx.measureText(string).width / 2, rDimensions.y + 20);
    }
  };