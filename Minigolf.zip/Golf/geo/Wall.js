class Wall extends Geometry {
    constructor(a, b) {
        super();
        this.coefficients = {A: 0, B: 0};
        this.width = 1;
        this.height = 1;
        // JS doesn't allow multiple constructors, so we'll examine the constructor arguments to see what we should do.
        // Cases:
        // No parameters -> create a default rectangle
        // One parameter -> Expect either another AxisAlignedRectangle (copy constructor) or Vector2 (widthHeight) 
        // Two parameters -> Expect two floats as width, height
    
        if (!b) {
          //If we get here, we have exactly one parameter
          if (a instanceof Wall) {
            this.coefficients = a.coefficients;
            this.width = a.width;
            return;
          }
          if( a > 90){
            throw "Bad parameter type in Wall constructor";
          }
          a = a / 180 * 3.14159;
          
          this.coefficients = {A: Math.sin(a), B: Math.cos(a)};
          //If we get here, we have one argument but of the wrong type
          throw "Bad parameter type in AxisAlignedRectangle constructor";
        }
        //If we get here we have two arguments
        if (!typeof a === "number" || !typeof b === "number")
          throw "Bad parameter type in AxisAlignedRectangle constructor";
        //If we get here we have two numbers as arguments
        if(a < 90){
            this.width = b;
        } else {
            this.height = b;
        }
        a = a / 180 * 3.14159;
        if (a == 0){ a = .01;}
        this.coefficients = {A: Math.sin(a), B: Math.cos(a)};
        
        
    
      }
}