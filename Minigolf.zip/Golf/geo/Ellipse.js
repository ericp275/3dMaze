class Ellipse extends Geometry {
    constructor(length, angle, width) {
      super();
      //console.log("L:" + length + " A:" + angle + " W:" + width);
      this.length = 0.5;
      this.angle = 0;
      this.width = 0.5;
  
      // Handle constructor arguments
      // There are three cases we check for
      // No arguments -> use default values
      // One argument + argument is a number -> treat argument as the new radius
      // One argument + argument is another circle -> treat constructor as a copy constructor
  
      if (!length) {
        //use default values
        return;
      }
      //If we get here, we have an argument
      if (length instanceof Ellipse) {
        this.length = a.length;
        return;
      }
      if (typeof length == "number") {
        this.length = length;
        
      } else {
        throw "Bad parameter type in ellipse constructor";
      }
      
      if (typeof angle == "number") {
        this.angle = angle;
        
      } else {
        console.log("bad angle");
        throw "Bad parameter type in ellipse constructor";
      }

      if (!width) {
          console.log("no width");
        //use default values
        return;
      }
      if (typeof width == "number") {
        this.width = width;
        return;
      } else {
        console.log("bad width");
        throw "Bad parameter type in ellipse constructor";
      }

    }
  }