class Boarder extends Good {
    constructor(a, b, type) {
        super(a, b, type);

        this.active = true;
    }

    makeInactive(){
        this.active = false;
        this.components[1].color = "LightGray";
    }

    makeActive(){
        this.active = false;
        this.components[1].color = "grey";
    }
}