class Geometry{
    constructor(type){
      this.type = type;
      
    }
  
  }