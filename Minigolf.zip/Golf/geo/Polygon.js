class Polygon extends Geometry {
    constructor(type) {
        super(type);
    }
}