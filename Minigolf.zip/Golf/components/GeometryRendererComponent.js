class GeometryRendererComponent extends RendererComponent {
    constructor(color, geometry) {
      super()
      this.color;
      this.geometry;
      this.visible = true;
      this.vertices = [];
      this.animatedVertices = [];
  
      // Check the arguments. We expect exactly two. 
      // The first is a color
      // The second is a geometry
  
      this.color = color;
      this.geometry = geometry;
      if(geometry.type == "Sand"){
        this.color = "yellow";
      } else if (geometry.type == "Water"){
        this.color = "blue";
      }
      this.hasImage = false;
      this.image = "";
    }
  
    render(ctx, gameObject) {
  
      ctx.fillStyle = this.color;
  
      if (this.geometry instanceof AxisAlignedRectangle) {
        let width = this.geometry.widthHeight.x;
        let height = this.geometry.widthHeight.y;
  
        let x = -width / 2;
        let y = -height / 2;
  
        ctx.fillRect(x, y, width, height);
  
      }

      else if (this.geometry instanceof Wall) {
        let width = this.geometry.width;
        let height = this.geometry.height;

        let A = this.geometry.coefficients.A;
        let B = this.geometry.coefficients.B;
        ctx.strokeStyle = this.color;
        ctx.lineWidth = .05;
        ctx.beginPath();
        ctx.moveTo(0 + .25 * A - .25 * B, 0 + .25 * A + .25 * B);
        ctx.lineTo(width * A - .25 * A - .25 * B, width * B + .25 * A - .25 * B);
        ctx.lineTo(width * A - height * B - .25 * A + .25 * B, width * B + (height * A) - .25 * A - .25 * B);
        ctx.lineTo(-(height * B) + .25 * A + .25 * B, (height * A) - .25 * A + .25 * B);
        ctx.fill();
      }

      else if (this.geometry instanceof Circle) {
        if(this.visible){
        ctx.fillStyle = this.color;
  
        ctx.beginPath();
        ctx.ellipse(0, 0, this.geometry.radius, this.geometry.radius, 0, 0, Math.PI * 2);
        ctx.fill();
        }
      }


      else if (this.geometry instanceof Ellipse) {
        ctx.fillStyle = this.color;
        let length = this.geometry.length;
        
  
        ctx.beginPath();
        ctx.ellipse( 0, 0, length - .5, this.geometry.width - .5, this.geometry.angle, 0, Math.PI * 2);
        ctx.fill();
      }


      else if (this.geometry instanceof Vector2) {
        ctx.strokeStyle = this.color;
        ctx.lineWidth = .05;
  
        ctx.beginPath();
        ctx.moveTo(this.geometry.x - .25, 0);
        ctx.lineTo(this.geometry.x + .25, 0);
        ctx.moveTo(0, this.geometry.y + .25);
        ctx.lineTo(0, this.geometry.y - .25);
        ctx.stroke();
  
       
      }

      else if (this.geometry instanceof Polygon) {
        
        
        ctx.strokeStyle = this.color;
        
        //console.log("coloring" + ctx.strokeStyle);
        ctx.lineWidth = .05;
        

        //console.log(this.vertices);
        if(!this.hasImage){
        ctx.beginPath();
        ctx.moveTo(this.animatedVertices[0].x, this.animatedVertices[0].y);
        for(var i = this.animatedVertices.length - 1; i >= 0; i--){
        ctx.lineTo(this.animatedVertices[i].x, this.animatedVertices[i].y);
        }
        ctx.fill();
        } else {
          //var img = this.image;
          ctx.rotate(this.angle);
          ctx.scale(1, -1);
          
          ctx.drawImage(this.image, 0, 0, this.length, this.width);
        }
      }
  
      else if (this.geometry instanceof Vector3) {
        if(this.geometry.animatedLength > .4){
        ctx.strokeStyle = "white";
        ctx.lineWidth = .1;
  

        let force = new Vector2();

        let slope = Math.atan((this.geometry.force.y - this.geometry.ball.y) / (this.geometry.force.x - this.geometry.ball.x)) + 3.1416 / 2;
        if (this.geometry.force.x <= this.geometry.ball.x){
          force.y = this.geometry.ball.y + Math.cos(slope) * this.geometry.animatedLength;
          force.x = this.geometry.ball.x - Math.sin(slope) * this.geometry.animatedLength;
        } else {
          force.y = this.geometry.ball.y - Math.cos(slope) * this.geometry.animatedLength;
          force.x = this.geometry.ball.x + Math.sin(slope) * this.geometry.animatedLength;
        }

        

        ctx.beginPath();
        var i = 0;
        for( i = 0; i < 10; i+=2){
          let j = i + 1;
          ctx.moveTo((this.geometry.ball.x * i + force.x * (10 - i)) / 10, (this.geometry.ball.y * i + force.y * (10 - i)) / 10);
          ctx.lineTo((this.geometry.ball.x * j + force.x * (10 - j)) / 10, (this.geometry.ball.y * j + force.y * (10 - j)) / 10);
        }
        ctx.stroke();

        ctx.fillStyle = this.color;
        
        
        ctx.moveTo(force.x + .25 * Math.cos(slope), force.y + .25 * Math.sin(slope));
        ctx.lineTo(force.x - .4 * Math.cos(slope), force.y -.4 * Math.sin(slope));
        ctx.lineTo(force.x - .4 * Math.cos(slope) + .2 * Math.cos(slope - 3.1416 / 2), force.y -.4 * Math.sin(slope) + .2 * Math.sin(slope - 3.1416 / 2));
        ctx.lineTo(force.x + .25 * Math.cos(slope) + .2 * Math.cos(slope - 3.1416 / 2), force.y + .25 * Math.sin(slope) + .2 * Math.sin(slope - 3.1416 / 2));
        ctx.fill();
      }
  
    }
    }
  }