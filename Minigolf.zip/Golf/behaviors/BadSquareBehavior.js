class BadSquareBehavior extends Behavior{
    constructor(){
      super();
      this.speed = new Vector2();
      this.speedy = false;
      this.sand = false;
    }
    update(){
      if (this.getSpeed() > .5) {
        this.transform.position.x += this.speed.x / 30; /// speed is in units/s * s
        this.transform.position.y += this.speed.y /30;
        if (this.getSpeed() > 3 || !this.speedy){
          this.speed.scale(.985);
        } else {
          console.log("HEY");
          this.speed.scale(.94);
        }
        if (this.sand){
          this.speed.scale(.91);
        }
        //console.log(this.speed)
        //console.log("X-->", this.transform.position.x);
        //console.log("Y-->" + this.transform.position.y);
      }
      else {
          this.speed = new Vector2();
          this.speedy = false;
      }
    }

    getSpeed(){
      return Math.abs(this.speed.x) + Math.abs(this.speed.y);
    }
    
  
  }