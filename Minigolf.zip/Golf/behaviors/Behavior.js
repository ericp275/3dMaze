class Behavior{
    constructor(){
      this.transform;
    }
  }