class ConvexObstacle extends Obstacle{
    constructor(vertices, animatedVertices, type){
        super();
        this.vertices = vertices;
        this.type = type;
        //this.animatedVerticies = animatedVerticies;
        var myGeometry = new Polygon(type);
        console.log("Made shape with " + this.vertices.length + " sides.");
        var myGeometryComponent = new GeometryComponent(myGeometry);
        this.components.push(myGeometryComponent);
    
        this.color = "grey";
        if(this.color.type == "water"){
          this.color = "blue";
        } else if (this.type == "sand"){
          this.color = "yellow";
        }
        var myRenderer = new GeometryRendererComponent(this.color, myGeometry);
        myRenderer.vertices = vertices;
        myRenderer.animatedVertices = animatedVertices;
        myRenderer.type = type;
        this.components.push(myRenderer);
        this.renderer = myRenderer;
        
  
      }
}