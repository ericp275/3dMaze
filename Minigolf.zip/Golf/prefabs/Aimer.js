class Aimer extends GameObject {
    constructor(ballx, bally, forcex, forcey){
      super();
      
      var golfBall = new Vector2(ballx, bally);
      var force = new Vector2(forcex, forcey)
      var myGeometry = new Vector3(golfBall, force);
      var myGeometryComponent = new GeometryComponent(myGeometry);
      this.components.push(myGeometryComponent);
  
      var myRenderer = new GeometryRendererComponent("black", myGeometry);
      this.components.push(myRenderer);
      this.renderer = myRenderer;
      

    }
    
    getSpeed(){
      let geo = this.components[0].Geometry;
      let dist = Math.sqrt((geo.ball.x - geo.force.x) * (geo.ball.x - geo.force.x) + (geo.ball.y - geo.force.y) * (geo.ball.y - geo.force.y));
      return new Vector2((geo.ball.x - geo.force.x) * (2 + dist), (geo.ball.y - geo.force.y) * (2 + dist));
    }

    setForce(force){
      this.components[0].Geometry.force = force;
      this.components[0].Geometry.resetLength();
    }
    
  }