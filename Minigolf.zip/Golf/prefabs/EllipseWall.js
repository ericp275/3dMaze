class EllipseWall extends Obstacle {
    constructor(l, a, w){
      super(); 
      a = a / 180 * 3.14159;   
      this.length = l;
      this.angle = a;
      this.width = w;
      var myGeometry = new Ellipse(l , a, w);
      var myGeometryComponent = new GeometryComponent(myGeometry);
      this.components.push(myGeometryComponent);
  
      var myRenderer = new GeometryRendererComponent("gray", myGeometry);
      this.components.push(myRenderer);
      this.renderer = myRenderer;
      this.vertices = this.setVetices();
      //console.log(this.vertices);
    }
    


    setVetices(){
      var vertices = [];
      for(var i = -3; i < 4; i++){
        var coeff = i / 3;
        if (coeff > 0){
          coeff = Math.sqrt(coeff);
        } else {
          coeff = -1 * Math.sqrt(-coeff);
        }
        var x = coeff * this.length;
        let width = this.width;
        var y = Math.sqrt((1 - (x * x) / (this.length * this.length)) * (width * width));
        let angle = this.angle;
        var rx = x * Math.cos(angle) - y * Math.sin(angle);
        var ry = x * Math.sin(angle) + y * Math.cos(angle);
        var point = {x: rx + this.transform.position.x, y: ry + this.transform.position.y};
        vertices[i + 3] = point;
        //console.log(x + ", " + y);
        if(Math.abs(i) < 3){
          rx = x * Math.cos(angle) + y * Math.sin(angle);
          ry = x * Math.sin(angle) - y * Math.cos(angle);
          var point = {x: rx + this.transform.position.x, y: ry + this.transform.position.y};
          
          vertices[12 - (i + 3)] = point;
        }
    }
    return vertices;
  }
    
  } 