class Rotator extends ConvexObstacle {
    constructor(vertices, animatedVertices, type){
      super(vertices, animatedVertices, type);
      

        
    }
}