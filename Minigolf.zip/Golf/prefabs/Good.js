class Good extends Obstacle {
    constructor(a, b, type){
      super(type);
      
      var myGeometry = new Wall(a,b, type);
      //console.log("wall constructed: " + myGeometry.coefficients.A + ", " + myGeometry.coefficients.B + " Width: " + myGeometry.width);
      var myGeometryComponent = new GeometryComponent(myGeometry);
      this.components.push(myGeometryComponent);
  
      var myRenderer = new GeometryRendererComponent("grey", myGeometry);
      this.components.push(myRenderer);
      this.renderer = myRenderer;
  
      var myBehavior = new GoodSquareBehavior();
      myBehavior.transform = this.transform;
      this.components.push(myBehavior);



      let width = this.components[0].Geometry.width;
      let height = this.components[0].Geometry.height;
      let A = this.components[0].Geometry.coefficients.A;
      let B = this.components[0].Geometry.coefficients.B;
      let shiftx = this.transform.position.x;
      let shifty = this.transform.position.y;

      this.vertices.push( new Vector2(0 + shiftx, 0 + shifty) );
      this.vertices.push( new Vector2(width * A + shiftx, width * B + shifty) );
      this.vertices.push( new Vector2(width * A - (height * B) + shiftx, width * B + (height * A) + shifty) );
      this.vertices.push( new Vector2(-(height * B) + shiftx, (height * A) + shifty) );

      

    }
    
    
    

    


    

    containsPoint(point){
      let width = this.components[0].Geometry.width;
      let height = this.components[0].Geometry.height;
      let A = this.components[0].Geometry.coefficients.A;
      let B = this.components[0].Geometry.coefficients.B;
      let shiftx = this.transform.position.x;
      let shifty = this.transform.position.y;
      if(Math.abs(A) < .001){
        if (point.x < 0 + shiftx && point.x > -1 + shiftx && point.y > 0 + shifty && point.y < width + shifty){
          return true;
        }
        return false;
      }
      let corner1 = new Vector2(0 + shiftx, 0 + shifty);
      let corner2 = new Vector2(width * A + shiftx, width * B + shifty);
      let corner3 = new Vector2(width * A - (height * B) + shiftx, width * B + (height * A) + shifty);
      let corner4 = new Vector2(-(height * B) + shiftx, (height * A) + shifty);
      
      if(this.getSide(corner1, corner2, point) < 0){
        if(this.getSide(corner2, corner3, point) > 0){
          if(this.getSide(corner3, corner4, point) > 0){
            if(this.getSide(corner4, corner1, point) < 0){
              return true;
            }
          }
        }
      }
      return false;
    }

    getDeflection(point, force){
      let width = this.components[0].Geometry.width;
      let A = this.components[0].Geometry.coefficients.A;
      let B = this.components[0].Geometry.coefficients.B;
      let shiftx = this.transform.position.x;
      let shifty = this.transform.position.y;
      
      let corner1 = new Vector2(0 + shiftx, 0 + shifty);
      let corner2 = new Vector2(width * A + shiftx, width * B + shifty);
      let corner3 = new Vector2(width * A - B + shiftx, width * B + A + shifty);
      let corner4 = new Vector2(-B + shiftx, A + shifty);
      
      if(this.getSide(corner1, corner2, point) < 0){
        if(this.getSide(corner2, corner3, point) > 0){
          if(this.getSide(corner3, corner4, point) > 0){
            console.log("4: " + corner4 + " , " + corner1 + " p " + point);
            return this.getDeflectionWall(corner4, corner1, force);
          } else{
            console.log("3: " + corner3 + " , " + corner4 + " p " + point);
            return this.getDeflectionWall(corner3, corner4, force);
          }
        } else {
          console.log("2: " + corner2 + " , " + corner3 + " p " + point);
          return this.getDeflectionWall(corner2, corner3, force);
        }
      }
      console.log("1: " + corner1 + " , " + corner2 + " p " + point);
      return this.getDeflectionWall(corner1, corner2, force);
    }
    
    getSide(p, q, r){
      if (p.x == q.x){
        
          return r.x - p.x;
        
      }
      let slope = (p.y - q.y) / (p.x - q.x);
      let offset = r.x - p.x;
      let lineHieght = offset * slope + p.y;
      return Math.sign(lineHieght - r.y);
    }

    

  }