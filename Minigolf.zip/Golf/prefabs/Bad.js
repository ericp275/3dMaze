class Bad extends GameObject {
    constructor(){
      super();    
  
      var myGeometry = new Circle(.25, "Solid");
      var myGeometryComponent = new GeometryComponent(myGeometry);
      this.components.push(myGeometryComponent);
  
      var myRenderer = new GeometryRendererComponent("white", myGeometry);
      this.components.push(myRenderer);
      this.renderer = myRenderer;

      var myBehavior = new BadSquareBehavior();
      myBehavior.transform = this.transform;
      this.components.push(myBehavior);
    }

    toggleSand(){
      this.components[2].sand = !this.components[2].sand;
      console.log("toggled sand to " + this.components[2].sand);
    }
    
    
  } 