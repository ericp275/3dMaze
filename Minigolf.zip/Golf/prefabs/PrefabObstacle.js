class PrefabObstacle extends Obstacle{
    constructor(length, angle, image){
        super("Solid");

        this.length = length;
        this.ratio = 0;
        this.width = 1;
        this.angle = angle + 3.14159;
        switch(image){
            case "boat":
            this.ratio = (225 / 473);
            this.width = length * this.ratio;
            this.vertices = [{x: 0, y: 0}, {x: length, y: 0}, {x: length, y: - this.width}, {x: 0, y: - this.width}];
        }

        let vertices = this.vertices;
        for(var i = 0; i < vertices.length; i++){
            vertices[i] = { x: vertices[i].x * Math.cos(this.angle) - vertices[i].y * Math.sin(this.angle), 
                            y: vertices[i].x * Math.sin(this.angle) + vertices[i].y * Math.cos(this.angle)}
        }
        
        //this.animatedVerticies = animatedVerticies;
        var myGeometry = new Polygon();
        console.log("Made shape with " + this.vertices.length + " sides.");
        var myGeometryComponent = new GeometryComponent(myGeometry);
        this.components.push(myGeometryComponent);
    
        var myRenderer = new GeometryRendererComponent("grey", myGeometry);
        myRenderer.vertices = vertices;
        
        myRenderer.hasImage = true;
        myRenderer.image = document.getElementById("buildImage");
        myRenderer.width = this.width;
        myRenderer.length = this.length;
        myRenderer.angle = this.angle;
        console.log("Angle: " + this.angle);
        this.components.push(myRenderer);
        this.renderer = myRenderer;
        
  
      }
}