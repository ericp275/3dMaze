class Marker extends GameObject {
    constructor(color){
      super();   
  
      var myGeometry = new Ellipse(.7 , 0, .7);
      var myGeometryComponent = new GeometryComponent(myGeometry);
      this.components.push(myGeometryComponent);
  
      var myRenderer = new GeometryRendererComponent(color, myGeometry);
      this.components.push(myRenderer);
      this.renderer = myRenderer;

    }
    
    
  } 